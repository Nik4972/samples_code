<!DOCTYPE HTML>
<html lang="ru-RU">
<head>
   <meta charset="UTF-8">
   <title><?php echo e($title); ?></title>
   
   <link rel="stylesheet" href="css/style.css">
</head>

<body>

      <center><h1> <?php echo $pagetitle; ?> </h1></center>

<div class="messages">

<table class="table table-bordered" border="1" width="100%" bgcolor="#0">
<tr><th style="text-align:center"><font color=white</font>Фамилия</th> <th style="text-align:center"><font color=white</font>Имя</th> <th style="text-align:center"> <font color=white</font>Отчество</th>
<th style="text-align:center"> <font color=white</font>Дата рождения</th> <th style="text-align:center"> <font color=white</font>Email</th> <th style="text-align:center"> <font color=white</font>Username</th> <th style="text-align:center"> <font color=white</font>Password</th> <th style="text-align:center"> <font color=white</font>Удл</th> </tr>

<?php echo Form::open(array('route' => 'del', 'method'=>'POST')); ?>


<?php foreach($messages as $message): ?>

<tr bgcolor="#FFFFE1">
<td><?php echo e($message->FAM); ?></td><td><?php echo e($message->NAME); ?></td><td><?php echo e($message->NAME2); ?></td>
<td><?php echo e($message->DR); ?></td>  <td><?php echo e($message->EMAIL); ?></td> <td><?php echo e($message->USERNAME); ?></td><td><?php echo e($message->PASSWORD); ?></td> 
<td><input type="checkbox" name="item[]" value="<?php echo e($message->ID); ?>" /></td>
</tr>

<?php endforeach; ?>

</table>

<center><input type="submit" style="color:blue" name="submitForm" value="Удалить отмеченные" /></center>
<?php echo Form::close(); ?>


<form name="otchet" action="/code/phpex2.php" method="post" enctype="multipart/form-data" target="_self">
<div align="center" style="color:#FFF">
<p><h4>Формирование отчета по базе данных </h4></p>
<p><input type="submit" style="color:blue" value="Сформировать"></p>
</div>
</form>

<!--
<?php echo Form::open(array('route' => 'export', 'method'=>'POST')); ?>

<center><input type="submit" style="color:blue" name="submitForm" value="Сформировать отчет" /></center>
<?php echo Form::close(); ?>

-->

</div>

</body>
</html>
