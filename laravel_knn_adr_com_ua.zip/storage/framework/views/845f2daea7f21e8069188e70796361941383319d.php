<!DOCTYPE HTML>
<html lang="ru-RU">
<head>
   <meta charset="UTF-8">
   <title><?php echo e($title); ?></title>
   
   <link rel="stylesheet" href="css/style.css">
</head>

<body>

      <center><h1> <?php echo $pagetitle; ?> </h1></center>

<div class="messages">

<table class="table table-bordered" border="1" width="100%" bgcolor="#0">

<tr><th style="text-align:center"><font color=white</font>Фамилия</th> <th style="text-align:center"><font color=white</font>Имя</th> <th style="text-align:center"> <font color=white</font>Отчество</th>
<th style="text-align:center"> <font color=white</font>Дата рождения</th> <th style="text-align:center"> <font color=white</font>Email</th> <th style="text-align:center"> <font color=white</font>Username</th> <th style="text-align:center"> <font color=white</font>Password</th> </tr>

<tr bgcolor="#FFFFE1">
<td style="text-align:center"><?php echo e($messages->FAM); ?></td>
<td style="text-align:center"><?php echo e($messages->NAME); ?></td>
<td style="text-align:center"><?php echo e($messages->NAME2); ?></td>
<td style="text-align:center"><?php echo e($messages->DR); ?></td>
<td style="text-align:center"><?php echo e($messages->EMAIL); ?></td>
<td style="text-align:center"><?php echo e($messages->USERNAME); ?></td>
<td style="text-align:center"><?php echo e($messages->PASSWORD); ?></td> 
</tr>

</table>

</div>

</body>
</html>
