<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<title>Input</title>
<link rel="stylesheet" href="css/bootstrap.min.css"> 
    <style type="text/css">
       body
            {
             font-family: sans-serif;
             margin: 0;

             background: #000 url(/images/citylights_full2.jpg) no-repeat center center fixed;
             -webkit-background-size: cover;
             -moz-background-size: cover;
             -o-background-size: cover;
              background-size: cover;
             }

     </style>>

<!-- <link rel="stylesheet" href="css/style.css"> -->

</head>

<!-- <body background="images/citylights_full2.jpg"> -->

<body>

<center>
<h1 style="color:blue">Введите Ваши данные</h1>
</center>

<?php echo Form::open(array('route' => 'contact_store', 'method'=>'POST', 'class' => 'form-horizontal')); ?>


<div class="form-group">
    <?php echo Form::label('FAM', 'Фамилия', ['class'=>'control-label col-xs-1', 'style'=>'color:white']); ?>


    <?php echo Form::text('FAM', null, 
        array('required', 
              'class'=>'col-xs-9', 
              'placeholder'=>'Ваша фамилия',
              'oninvalid'=>"this.setCustomValidity('Введите Вашу фамилию!')"
              )); ?>

</div>
<center><p class="text-danger"> <?php echo e($errors->first('FAM')); ?> </p> </center>

<div class="form-group">
    <?php echo Form::label('NAME', 'Имя', ['class'=>'control-label col-xs-1', 'style'=>'color:white']); ?>


    <?php echo Form::text('NAME', null, 
        array('required', 
              'class'=>'col-xs-9', 
              'placeholder'=>'Ваше имя',
              'oninvalid'=>"this.setCustomValidity('Введите Ваше имя!')"
              )); ?>

</div>
<center><p class="text-danger"> <?php echo e($errors->first('NAME')); ?> </p> </center>


<div class="form-group">
    <?php echo Form::label('NAME2', 'Отчество', ['class'=>'control-label col-xs-1', 'style'=>'color:white']); ?>


    <?php echo Form::text('NAME2', null, 
        array('required', 
              'class'=>'col-xs-9', 
              'placeholder'=>'Ваше отчество',
              'oninvalid'=>"this.setCustomValidity('Введите Вашу отчество!')"
              )); ?>

</div>
<center><p class="text-danger"> <?php echo e($errors->first('NAME2')); ?> </p> </center>

<div class="form-group">
    <?php echo Form::label('DR', 'Дата рожд', ['class'=>'control-label col-xs-1', 'style'=>'color:white']); ?>


    <?php echo Form::text('DR', null, 
        array('required', 
              'class'=>'col-xs-9', 
              'placeholder'=>'Дата Вашего рождения дд.мм.гггг',
              'oninvalid'=>"this.setCustomValidity('Введите дату Вашего рождения!')"
              )); ?>

</div>
<center><p class="text-danger"> <?php echo e($errors->first('DR')); ?> </p> </center>


<div class="form-group">
    <?php echo Form::label('EMAIL', 'E-mail', ['class'=>'control-label col-xs-1', 'style'=>'color:white']); ?>

    <?php echo Form::text('EMAIL', null, 
        array('required', 
              'class'=>'col-xs-9', 
              'placeholder'=>'Ваш e-mail адрес',
              'oninvalid'=>"this.setCustomValidity('Введите Ваш e-mail адрес!')"
              )); ?>

</div>
<center><p class="text-danger"> <?php echo e($errors->first('EMAIL')); ?> </p> </center>

<div class="form-group">
    <?php echo Form::label('USERNAME', 'Login', ['class'=>'control-label col-xs-1', 'style'=>'color:white']); ?>


    <?php echo Form::text('USERNAME', null, 
        array('required', 
              'class'=>'col-xs-9', 
              'placeholder'=>'Ваше имя пользователя',
              'oninvalid'=>"this.setCustomValidity('Введите Ваше имя пользователя!')"
              )); ?>

</div>
<center><p class="text-danger"> <?php echo e($errors->first('USERNAME')); ?> </p> </center>


<div class="form-group">
    <?php echo Form::label('PASSWORD', 'Пароль', ['class'=>'control-label col-xs-1', 'style'=>'color:white']); ?>

    <?php echo Form::text('PASSWORD', null, 
        array('required', 
              'class'=>'col-xs-9', 
              'placeholder'=>'Ваш пароль',
              'oninvalid'=>"this.setCustomValidity('Введите Ваш пароль!')"
              )); ?>

</div>
<center>
     <p class="text-danger"> <?php echo e($errors->first('PASSWORD')); ?> </p>

<div class="form-group">
    <?php echo Form::submit('Отправить', array('class'=>'btn btn-primary')); ?>

</div>
</center>

<?php echo Form::close(); ?>


</body>
</html>
