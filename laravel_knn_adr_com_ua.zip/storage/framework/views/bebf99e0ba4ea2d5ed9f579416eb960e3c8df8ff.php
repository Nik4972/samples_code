<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Курс USD</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<font color="white"</font>
<h1 align="center">Курсы валют НБУ на сегодня <?php echo e(date("d.m.Y H:i:s")); ?> </h1>
<h2 align="center">USD - <?php echo e($rateusd); ?></h2>
<h2 align="center">EUR - <?php echo e($rateeur); ?></h2>
<h2 align="center">RUB - <?php echo e($raterur); ?></h2>
</body>
</html>
