<!DOCTYPE HTML>
<html lang="ru-RU">
<head>
   <meta charset="UTF-8">
   <title><?php echo e($title); ?></title>
   <script type="text/javascript" src="js/jquery.min.js"></script>
   <script type="text/javascript" src="js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="css/bootstrap.min.css" />
   <script type="text/javascript" src="js/script.js"></script>
     <style type="text/css">
       body
            {
             font-family: sans-serif;
             margin: 0;

             background: #000 url(/images/citylights_full2.jpg) no-repeat center center fixed;
             -webkit-background-size: cover;
             -moz-background-size: cover;
             -o-background-size: cover;
              background-size: cover;
             }

     </style>>

</head>

<!-- <body background="images/citylights_full2.jpg"> -->
<body>

   <div class="container">
   <center>
      <h1><?php echo $pagetitle; ?></h1><hr/>
   </center>
<!--    <form method="POST" action="/save" id="id-form_messages" onsubmit="alert('Данные записаны в базу данных.');"> -->

<?php echo Form::open(array('route' => 'save', 'method'=>'POST', 'id'=>'id-form_messages')); ?>


<div class="form-group">
<label for="name" style="color:white">Имя: *</label>
<input class="form-control" placeholder="Имя" name="name" type="text" id="name">
</div>

<div class="form-group">
<label for="email" style="color:white">E-Mail:</label>
<input class="form-control" placeholder="E-Mail" name="email" type="email" id="email">
</div>

<div class="form-group">
<label for="message" style="color:white">Сообщение:</label>
<textarea class="form-control" rows="5" placeholder="Тест сообщения" name="message" cols="50" id="message"></textarea>
</div>

<div class="form-group">
<input class="btn btn-primary" type="submit" value="Добавить">
</div>
<!-- </form> -->

<?php echo Form::close(); ?>


<div class="text-right"><b style="color:white">Всего сообщений:</b> <i class="badge"><?php echo e($count); ?></i></div><br/>
<div class="messages">

<?php if( ! $messages->isEmpty() ): ?>

<?php foreach($messages as $message): ?>
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">
<span>
#<?php echo $message->id; ?>

<?php if ( ! (empty($message->email))): ?>
   <a href="mailto:<?php echo e($message->email); ?>"><?php echo e($message->name); ?></a>
<?php else: ?>
  <?php echo e($message->name); ?>

<?php endif; ?>
</span>



<span class="pull-right label label-info"><?php echo e($message->created_at); ?></span>
</h3>
</div>

<div class="panel-body"><?php echo e($message->message); ?><hr/>
<div class="pull-right">
<a class="btn btn-info" href="#">
<i class="glyphicon glyphicon-pencil"></i>
</a>
<a class="btn btn-danger" href="/delete/<?php echo e($message->id); ?>" onClick="alert('Запись успешно удалена.');" >
<i class="glyphicon glyphicon-trash"></i>
</a>
</div>
</div>
</div>
<?php endforeach; ?>

<!-- Pagination -->
<div class="text-center">
<?php echo $messages->render(); ?>

</div>

<?php endif; ?>
</div>
   </div>
</body>
</html>
