<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Курс USD</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<font color="white"</font>
<h1 align="center">Курсы валют НБУ на сегодня {{date("d.m.Y H:i:s")}} </h1>
<h2 align="center">USD - {{$rateusd}}</h2>
<h2 align="center">EUR - {{$rateeur}}</h2>
<h2 align="center">RUB - {{$raterur}}</h2>
</body>
</html>
