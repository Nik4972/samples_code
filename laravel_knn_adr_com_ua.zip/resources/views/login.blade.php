<!DOCTYPE html>
<html>
<head>
<!-- <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> -->
 <meta name="_token" content="{!! csrf_token() !!}"/>

<title>Вход/Регистрации</title>

<link rel="stylesheet" href="css/style.css">
<link rel="shortcut icon" href="/image/group.ico" type="image/x-icon">

</head>
<body>


{!! Form::open(array('route' => 'shower', 'method'=>'POST', 'id'=>'login', 'class' => 'form-horizontal')) !!}

    <h1>WELCOME</h1>
    <fieldset id="inputs">
        <input name="username" type="text" placeholder="Логин" autofocus required>
        <input name="password" type="password" placeholder="Пароль" required>
    </fieldset>
    <center><p class="text-danger" id="resultpost" style="color:red"> {{ $errors->first('username') }} </p> </center>

    <fieldset id="actions"> 
        
           {!! Form::submit('Войти', array('class'=>'btn btn-primary', 'id'=>"submit")) !!}

    <a href="javascript:void(0);" onClick="sm();">Забыли пароль?</a><a href="contact">Регистрация</a>  

     </fieldset> 

{!! Form::close() !!}

    <script src="{{ asset('js/jquery.min.js') }}"></script> 
    <script src="{{ asset('js/scripts.js') }}"></script>
    <script type="text/javascript">
    $.ajaxSetup({ headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') } });
    </script>


</body>
</html>
