<!DOCTYPE HTML>
<html lang="ru-RU">
<head>
   <meta charset="UTF-8">
   <title>{{ $title }}</title>
   
   <link rel="stylesheet" href="css/style.css">
</head>

<body>

      <center><h1> {!! $pagetitle !!} </h1></center>

<div class="messages">

<table class="table table-bordered" border="1" width="100%" bgcolor="#0">
<tr><th style="text-align:center"><font color=white</font>Фамилия</th> <th style="text-align:center"><font color=white</font>Имя</th> <th style="text-align:center"> <font color=white</font>Отчество</th>
<th style="text-align:center"> <font color=white</font>Дата рождения</th> <th style="text-align:center"> <font color=white</font>Email</th> <th style="text-align:center"> <font color=white</font>Username</th> <th style="text-align:center"> <font color=white</font>Password</th> <th style="text-align:center"> <font color=white</font>Удл</th> </tr>

{!! Form::open(array('route' => 'del', 'method'=>'POST')) !!}

@foreach ($messages as $message)

<tr bgcolor="#FFFFE1">
<td>{{ $message->FAM }}</td><td>{{ $message->NAME }}</td><td>{{ $message->NAME2 }}</td>
<td>{{ $message->DR }}</td>  <td>{{ $message->EMAIL }}</td> <td>{{ $message->USERNAME }}</td><td>{{ $message->PASSWORD }}</td> 
<td><input type="checkbox" name="item[]" value="{{ $message->ID }}" /></td>
</tr>

@endforeach

</table>

<center><input type="submit" style="color:blue" name="submitForm" value="Удалить отмеченные" /></center>
{!! Form::close() !!}

<form name="otchet" action="/code/phpex2.php" method="post" enctype="multipart/form-data" target="_self">
<div align="center" style="color:#FFF">
<p><h4>Формирование отчета по базе данных </h4></p>
<p><input type="submit" style="color:blue" value="Сформировать"></p>
</div>
</form>

<!--
{!! Form::open(array('route' => 'export', 'method'=>'POST')) !!}
<center><input type="submit" style="color:blue" name="submitForm" value="Сформировать отчет" /></center>
{!! Form::close() !!}
-->

</div>

</body>
</html>
