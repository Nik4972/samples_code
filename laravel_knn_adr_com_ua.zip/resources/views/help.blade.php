<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>My Help</title>
<link rel="stylesheet" href="css/style.css">

<style>
#center {
    top: 40%; /* Отступ в процентах от верхнего края окна */
    left: 50%; /* Отступ в процентах от левого края окна */
    width: 650px; /* Ширина блока */
    height: 570px; /* Высота блока */
    position: absolute; /* Абсолютное позиционирование блока */
    margin-top: -225px; /* Отрицательный отступ от верхнего края страницы, должен равняться половине высоты блока со знаком минус */
    margin-left: -325px; /* Отрицательный отступ от левого края страницы, должен равняться половине высоты блока со знаком минус */
    border: 1px solid #CCC;
    border-radius: 5px;
    background: #c0c0c0;
    font-size: 18px;
    text-align: left;
}
</style>
</head>
<body>

<div id="wrap">
    <div id="content" class="clearfix">
         <div id="center"><br><br><br>
<strong>Описание сайта.</strong><br><br>
Данный сайт разработан на фреймворке Laravel 5.<br>
При его разработке использовано большинство технологий<br>
необходимых для создания сайтов любого уровня сложности:<br><br>
- использование MVC фреймворка<br>
- использование маршрутизации страниц<br>
- работа с базами данных MySql<br>
- программирование на PHP, SQL, HTML5, CSS3, JavaScript<br>
- использование фреймворка BootStrap<br>
- использование CURL для выбора данных с сайта<br>
- распарсивание XML файлов<br>
- получение отчетов в Excel формате (меню "Login"->admin/admin)<br>
- получение и обработка ленты новостей с RSS канала<br>
- установка и настройка сайта на хостинге<br><br>

Навыки разработки прикладных приложений на языке С++<br>
можно посмотреть <a href=https://docs.google.com/presentation/d/1YbqsZSDmiALxLj4kxKTnh-kFfMBc09MmIRnWC_idSRY/edit?usp=sharing target="_blank">здесь.</a><br><br>
Желаю всем удачи и ищу взаимовыгодного сотрудничества с<br>
клиентами для реализации серьезных проектов.<br>
         </div>
    </div>
</div>
