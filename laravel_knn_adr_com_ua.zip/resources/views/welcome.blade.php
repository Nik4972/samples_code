<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<title>KNN Personal Site</title>
<link href="css/default.css" rel="stylesheet" type="text/css" />
<link href="css/welcome.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="/favicon.ico" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/mobilyslider.js" type="text/javascript"></script>
<script src="js/init.js" type="text/javascript"></script>

</head>
<body>
<ul id="nav">
<li><a href="">Resume</a>
    <ul>
     <li><a href="/images/konzerovsky_rezume_rus2.doc">ResumeRus</a></li>
     <li><a href="/images/konzerovsky_rezume_eng.doc ">ResumeEng</a></li>
   </ul>
</li>

<li><a href="/guest_book">Guest Book</a></li>

<li><a href="">Services</a>
    <ul>
     <li><a href="/news">News</a></li>
     <li><a href="/kurs">Valuta</a></li>
     <li><a href="/robots">Robots.txt analyzer</a></li>
   </ul>
</li>

<li><a href="/login">Login</a></li>
<li><a href="/help">Help</a></li>

</ul>
<div id="content">
<div class="slider slider2">
<div class="sliderContent">
<div class="item">
<img src="images/img1.jpg" alt="" />
</div>
<div class="item">
<img src="images/img2.jpg" alt="" />
</div>
<div class="item">
<img src="images/img3.jpg" alt="" />
</div>
<div class="item">
<img src="images/img4.jpg" alt="" />
</div>
<div class="item">
<img src="images/img5.jpg" alt="" />
</div>
<div class="item">
<img src="images/img6.jpg" alt="" />
</div>
</div>
</div>
</div><!-- end content -->


</body>
</html>
