<html>
<head>
<meta name="_token" content="{!! csrf_token() !!}">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Анализ robots.txt</title>
     <link rel="stylesheet" href="css/bootstrap.min.css"> 
     <script type="text/javascript" src="js/jquery.min.js"></script>
     <script type="text/javascript" src="js/scripts.js"></script>
</head>
<body background="images/bg.jpg">

<center>
    </br></br>

    <h1>Анализ robots.txt</h1>
    
    <h4>Введите адрес сайта в соответствии с приведенным форматом</h4></br>

    <form method="POST" id="formx" action="javascript:void(null);" onsubmit="call()">    
    <input id="kol" name="url" value="http://www.ukr.net" type="text" required="">
    <input value="Анализ" type="submit">
    </form>
    </br></br></br></br></br>
</center>    

<!--  Вывод таблицы с результатом !-->
    <div id="results"></div>

   <script type="text/javascript">
    $.ajaxSetup({ headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') } });
   </script>

</body>
</html>
