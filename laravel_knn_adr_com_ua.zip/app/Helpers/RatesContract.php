<?php

namespace App\Helpers;

Interface RatesContract
{

     public function getRates($cur);

}
