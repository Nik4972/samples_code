<?php

namespace App\Http\Controllers;

use Carbon\Carbon;

use Illuminate\Http\Request;
use Illuminate\Http\Response;

use App\Http\Requests;
use App\Http\Requests\ContactFormRequest;
use App\User;
use App\Helpers\RatesContract;
use App\Models\Message;
use Validator, Input, Redirect;

class AboutController extends Controller
{

    public function create()
    {
        return view('about.contact');
    }


    public function show(Request $request)
    {
 

    	$un   = $request['username'];
      $pass = $request['password'];

 

    	if ($un=='admin' & $pass=='admin')
            {
             // Вывод БД Users если ввели логин: admin  пароль: admin
             // Проверка пароля Админа

                   if (User::where('USERNAME', $un)->where('PASSWORD', $pass)->count() === 0)
                   {
                    
                    $error = ['username' => 'Неверный логин или пароль!'];
                    return redirect()->back()->withErrors($error);

                   } else {
        
            	// Вывод данных всех пользователя
      	
   	          $data = [
                   'title'    => 'Просмотр',
                   'pagetitle'=> '<p style="color:white">Просмотр базы данных</p>',
                   'messages' => User::all(),
                  ];


              return view('show',$data);


                   }

            } else 	{    // Проверка имени и пароля пользователя

                   if (User::where('USERNAME', $un)->where('PASSWORD', $pass)->count() === 0)
                   {
                    
                    $error = ['username' => 'Неверный логин или пароль!'];
                    return redirect()->back()->withErrors($error);

                   } else {


               // Вывод данных конкретного пользователя            
   	          $data = [
                   'title'    => 'Просмотр',
                   'pagetitle'=> '<p style="color:white">Просмотр личных данных</p>',
                   'messages' => User::where('USERNAME', $un)->where('PASSWORD', $pass)->first(),
                  ];

              return view('show_one',$data);

            }
         }  
    }

    public function mail($mail)
    {
 
      if (User::where('EMAIL', $mail)->count() === 0)
         {
            $error = ['username' => 'Email '.$mail. ' отсутствует в базе данных!'];
            return redirect('login')->withErrors($error);
         }

 
      \Mail::send('emails.contact',
        array(
            'name' => 'Babajka LTD',
            'email' => $mail,
            'user_message' => 'This is message!'
        ), function($message)
    {
        $message->from('admin@admin.com');
        $message->to('user@mail.com', 'Admin')->subject('Password recovery.');
    });

        $error = ['username' => $mail. ' отправлено письмо с паролем.'];

        return redirect('login')->withErrors($error);

    }  

    public function store(ContactFormRequest $request)
    {
    
            $all=$request->all();
            $all['DR'] = Carbon::createFromFormat('d.m.Y', $all['DR'])->format('Y-m-d');

            User::create($all);


  	 return \Redirect::route('contact')
      ->with('message', 'Thanks for contacting us!');

    }

  public function del(Request $request)
  {
     if ( isset ( $request['item'] ) )
     {
         $ids = implode( ',', $request['item'] );

         User::whereRaw('ID in ('.$ids.')')->delete();

         return \Redirect::route('login');
      }
  }

        public function guest_book()
         {
           $data = [
                   'title' => 'Гостевая книга',
                   'pagetitle'=> '<i style="color:blue">Гостевая книга</i>',
                   'messages' => Message::oldest()->paginate(2),
                   'count' => Message::count()

                  ];
           return view('guest',$data);
         }

         public function save(Request $request)
         {

         $v =\Validator::make($request->all(),
        [
        'name' => 'required',
        'email' => 'required|email',
        'message' => 'required',
        ]
        );
        if($v->fails())
        {

          foreach ($v->errors()->all() as $message)
             {
              echo $message."<br>";
             }
         return redirect()->back()->withErrors($v->errors());
        }
        else
        {
            $all=$request->all();
            Message::create($all);
            return back();
         }
    }


         public function delete($id)
         {
           if($id!=1){
             $m=Message::find($id);
             $m->delete();
             return back()->with('message','Запись успешно удалена.');
           }
           else {
               return back();
           }

         }

         public function kurs(RatesContract $rates){
            $rateUSD=$rates->getRates('USD');
            $rateEUR=$rates->getRates('EUR');
            $rateRUR=$rates->getRates('RUB');
            return view('kurs',['rateusd'=>$rateUSD,'rateeur'=>$rateEUR,'raterur'=>$rateRUR]);
        }

         public function news()
        {

            echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
            echo '<body background="images/bg.jpg">';
            
            include_once("code/write_rss.php");//подключаем файл с функцией вывода RSS-новостей
             //адресс новостей (URL-адрес RSS потока)
            $url_rss="http://www.news.yandex.ru/software.rss";
             //количество выводимых новостей
            $kol_print_news=10;
             //имя файла для хранения RSS-новостей на локальном сервере (кэш-файл)
            $file_rss="cache_rss.xml";
             //время обновления, в часах
            $hclock=1;
            print_rss($url_rss,$file_rss,$hclock,$kol_print_news); //вызываем функцию вывода RSS-новостей

            echo '</body>';
            echo "<center><p>&copy; 2015 KNN Dnepr<p></center>";    
        }

}
