<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Requests;

class RobotController extends Controller
{

public function ranaliz(Request $request)
{

if(!$head=@get_headers($request["url"], 1))
{
    echo '<center><h2 style="color:red">Сайт '.$request["url"]." отсутствует!</h2></center>";
    return;
}

$head=get_headers($request["url"].'/robots.txt', 1);
$content=file_get_contents($request["url"].'/robots.txt');

echo "<center><h1>Результат анализа<h1></center>";
echo "<table class=\"table table-bordered\" border=\"1\" width=\"100%\" bgcolor=\"#FFFFA1\">";
echo '<tr><th>№</th><th>Название проверки</th><th style="text-align:center">Статус</th><th>Текущее состояние</th><th>Рекомендации</th></tr>';

//Проверка наличия robots.txt
if(!strpos($head[0],'404'))
{
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>1</td><td>Наличия файла robots.txt</td><td style="color:green; text-align:center">OK</td><td>Файл robots.txt присутствует</td><td>Доработки не требуются.</td>';
  echo "</tr>";
 
}
else  {
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>1</td><td>Наличия файла robots.txt</td><td style="color:red; text-align:center">Ошибка</td><td>Файл robots.txt отсутствует</td><td>Создать файл robots.txt и разместить его на сайте.</td>';
  echo "</tr>";
  return false;
}

//Проверка наличия директивы Host в robots.txt
if(strpos($content,'Host:'))
{
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>6</td><td>Наличие директивы Host в файле robots.txt</td><td style="color:green; text-align:center">OK</td><td>Директива Host указана</td><td>Доработки не требуются.</td>';
  echo "</tr>";
}
else  {
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>6</td><td>Наличие директивы Host в файле robots.txt</td><td style="color:red; text-align:center">Ошибка</td><td>Директива Host не указана</td><td>Для того, чтобы поисковые системы знали, какая версия сайта является основных зеркалом, необходимо прописать адрес основного зеркала в директиве Host. В данный момент это не прописано. Необходимо добавить в файл robots.txt директиву Host. Директива Host задётся в файле 1 раз, после всех правил.</td>';
  echo "</tr>";
}

//Проверка количества директив Host в robots.txt
if(preg_match_all("|Host:|", $content) === 1)
{
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>8</td><td>Количество директив Host в файле robots.txt</td><td style="color:green; text-align:center">OK</td><td>Директива Host указана 1 раз</td><td>Доработки не требуются.</td>';
  echo "</tr>";
}
else  {
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>8</td><td>Количество директив Host в файле robots.txt</td><td style="color:red; text-align:center">Ошибка</td><td>Директива Host указана '.preg_match_all("|Host:|", $content).' раз</td><td>Директива Host должна быть указана в файле толоко 1 раз. Необходимо удалить все дополнительные директивы Host и оставить только 1, корректную и соответствующую основному зеркалу сайта.</td> ';
  echo "</tr>";
}

//Проверка размера robots.txt
if((strlen($content) == 0) || (strlen($content) > 32000))
{
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>10</td><td>Размер файла robots.txt</td><td style="color:red; text-align:center">Ошибка</td><td>Размера файла robots.txt составляет '.strlen($content).', что не соответствует норме.</td><td>Файл robots.txt не может быть пустым и быть больше 32 кб. Необходимо отредактировть файл robots.txt таким образом, чтобы его размер не превышал 32 Кб</td>';
  echo "</tr>";

}
else  {
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>10</td><td>Размер файла robots.txt</td><td style="color:green; text-align:center">OK</td><td>Размера файла robots.txt составляет '.strlen($content).', что соответствует норме.</td><td>Доработки не требуются.</td>';
  echo "</tr>";
}

//Проверка наличия директивы Sitemap в robots.txt
if(strpos($content,'Sitemap:'))
{
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>11</td><td>Наличие директивы Sitemap в файле robots.txt</td><td style="color:green; text-align:center">OK</td><td>Директива Sitemap указана.</td><td>Доработки не требуются.</td>';
  echo "</tr>";
}
else  {
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>11</td><td>Наличие директивы Sitemap в файле robots.txt</td><td style="color:red; text-align:center">Ошибка</td><td>В файле robots.txt не указана директива Sitemap</td><td>Добавить в файл robots.txt директиву Sitemap.</td>';
  echo "</tr>";
}

//Проверка кода ответа сервера на robots.txt
if(strpos($head[0],'200'))
{
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>12</td><td>Код ответа сервера для файла robots.txt</td><td style="color:green; text-align:center">OK</td><td>Файл robots.txt отдаёт код ответа сервера 200</td><td>Доработки не требуются.</td>';
  echo "</tr>";
}
else  {
  echo "<tr bgcolor=\"#FFFFE1\">";
  echo '<td>12</td><td>Код ответа сервера для файла robots.txt</td><td style="color:red; text-align:center">Ошибка</td><td>Файл robots.txt отдаёт код ответа сервера '.$head[0].'</td><td>Файл robots.txt должны отдавать код ответа 200, иначе файл не будет обрабатываться. Необходимо настроить сайт таким образом, чтобы при обращении к файлу robots.txt сервер возвращает код ответа 200</td>';
  echo "</tr>";
}

echo "</table>";


echo "<center><p>&copy; 2015 KNN Dnepr<p></center>";    


}

}
