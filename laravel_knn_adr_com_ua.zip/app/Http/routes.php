<?php


Route::get('/', function () {
    return view('welcome');
});

Route::any('login', ['as' => 'login', function () {
    return view('login');
}]);

Route::get('help', function () {
return view('help');
});

Route::get('kurs','AboutController@kurs');
Route::get('news','AboutController@news');

Route::any('robots', ['as' => 'robots', function () {
    return view('robots');
}]);

Route::post('ranaliz','RobotController@ranaliz');

Route::any('guest_book', ['uses'=>'AboutController@guest_book', 'as' =>'guest']);
Route::post('save', ['uses' => 'AboutController@save', 'as' =>'save']);
Route::any('delete/{id}', ['uses' => 'AboutController@delete', 'as' =>'delete']);
Route::get('mail/{mail}','AboutController@mail');

Route::get('contact', 
  ['as' => 'contact', 'uses' => 'AboutController@create']);

Route::post('contact', 
  ['as' => 'contact_store', 'uses' => 'AboutController@store']);

Route::any('shower', 
  ['as' => 'shower', 'uses' => 'AboutController@show']);

Route::post('export', 
  ['as' => 'export', 'uses' => 'AboutController@export']);

Route::post('del', 
  ['as' => 'del', 'uses' => 'AboutController@del']);



