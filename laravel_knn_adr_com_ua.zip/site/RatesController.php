<?php

namespace app\Helpers;

use App\Helpers\RatesContract;
use SimpleXMLElement;

class RatesController implements RatesContract
{

//     public function getRates($cur='USD'){
     public function getRates($cur){

          $xml=$this->getXML();
          return $this->procXML($xml,$cur);

      }
     private function getXML(){
/*
          $url='http://bank-ua.com/export/currrate.xml';
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
          return $result=curl_exec($ch);
*/
         return $result=file_get_contents('http://bank-ua.com/export/currrate.xml');
     }

     private function procXML($xml, $cur){
          $rates=new SimpleXMLElement($xml);
          foreach ($rates->item as $rate){
               if ($rate->char3==$cur){
                    return (string)$rate->rate/100;
               }
          }
     }
}


