<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class ExampleTest extends TestCase
{
    /**
     * A basic functional test example.
     *
     * @return void
     */
    public function testBasicExample()
    {
        $this->visit('/')
             ->see('KNN Personal Site');
    }

    public function testDatabase()
{
    // Сделать вызов в приложение...

    $this->seeInDatabase('users', ['EMAIL' => 'admin@ukr.net']);
}

public function testNewUserRegistration()
{
  $this->visit('login')
       ->type('admin', 'username')
       ->type('admin', 'password')
       ->press('Войти')
       ->seePageIs('shower');
}

}
