//Функция отправки рег. данных
function sm()
 {
  var YouMail=prompt("Введите E-Mail указанный при регистрации.", "nikon2001@ukr.net");
  document.location.href = "mail/"+YouMail;
 }

function AjaxFormRequest(result_id) {
//alert(url);
var YouMail=prompt("Введите E-Mail указанный при регистрации.", "nikon2001@ukr.net");

        $.ajax({
            url:     'mail/'+YouMail, //Адрес подгружаемой страницы
            type:     'GET', //Тип запроса
            dataType: 'html', //Тип данных
//            data: {"mail" : YouMail },
            data: "",
            success: function(response) { //Если все нормально
                var res =  $.parseJSON(response);
                    document.getElementById(result_id).innerHTML = res.message;
            },

error: function(xhr, status, error) {
    alert(xhr.responseText + '|\n' + status + '|\n' +error);
}
//            error: function(response) { //Если ошибка
//                document.getElementById(result_id).innerHTML = "Ошибка при отправке формы";
//            }

        });
    }


//Функция закрытия окна
function winClose(){
window.close('/code/send_mail2.php');
}


    /* Функция cal()
     * 1. Принимает данные из формы ввода
     * 2. Отправляет данные на сервер через Ajax
     * 3. Получает данные от сервера через Ajax
     * 4. Отправляет полученные данные на главную страницу в поле  c id="results"
     * 5. В случае сбоя при обработке данных сервером, отображает полученные ошибки
    */

    function call() {
    
          var msg = $('#formx').serialize();

            $.ajax({
              url: 'ranaliz',
              type: 'POST',
              dataType: 'html', //Тип данных              
              data: msg,
              success: function(data) {
                $('#results').html(data);
              },
              error:  function(xhr, str){
              alert('Ошибка обработки: ' + xhr.responseCode);
              }
            });
         }

