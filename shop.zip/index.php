<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Товар</title>
     <link rel="stylesheet" href="styles/bootstrap.min.css">
     <script type="text/javascript" src="js/jquery.min.js"></script>
     <script type="text/javascript" src="js/scripts.js"></script>
</head>
<body background="images/bg.jpg">

<?php

require_once ('connect.php');

$link = connect_db();

if ($link->connect_errno) {
    echo "Не удалось подключиться к MySQL: (" . $link->connect_errno . ") " . $link->connect_error;
}

if(!($query = $link->prepare("SELECT id, name FROM tovar order by name")))
	{
	 echo "Не удалось подготовить запрос: (" . $link->errno . ") " . $link->error;	
	}	

if(!$query->execute())
    {
	 echo "Не удалось выполнить запрос: (" . $query->errno . ") " . $query->error;
    }

$query->bind_result($id, $name);

?>

<center>
</br>
<div class="container">
    <div class="jumbotron"><h1>Интернет-магазин</h1></div>
    <legend><h3>Каталог</h3></legend>
</div>
    <!-- Формирование drop down list с названием товара и формы ввода -->

    <form method="POST" id="formx" action="javascript:void(null);" onsubmit="call()">
    
    <label for="tovar">Товар</label>

    <select name='tovar'>
      <?php
        while ($query->fetch()) {
          echo "<option value=$id>$name</option>"; 
        }
      ?>
    </select>

    <label for="kol">Количество</label>
    <input id="kol" name="kol" value="1" type="text">
    <input value="Добавить в корзину" type="submit">
    </form>
    </br></br></br>
</center>    
    
<!-- Вывод содержимого корзины -->
    <div id="results"></div> 

    <center><p>&copy; 2017 KNN Dnipro<p></center> 

</body>
</html>
