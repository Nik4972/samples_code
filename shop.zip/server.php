<?php

//Соединение с БД
require_once ('connect.php');
$link = connect_db();
if ($link->connect_errno) {
    echo "Не удалось подключиться к MySQL: (" . $link->connect_errno . ") " . $link->connect_error;
}

  if($_POST["idd"]) { // Удаление записи из корзины

if (!($query = $link->prepare("DELETE from trash WHERE id=?")))
  {
   echo "Не удалось подготовить запрос: (" . $link->errno . ") " . $link->error;  
  } 

if (!$query->bind_param("i", $_POST['idd']))
  {
     echo "Не удалось привязать параметры: (" . $query->errno . ") " . $query->error;   
  }

if (!$query->execute())
    {
   echo "Не удалось выполнить запрос: (" . $query->errno . ") " . $query->error;
    }

   }
    else { // Добавление записи в корзину

           //Проверка валидности количества товара
          if (!is_numeric($_POST["kol"]) || $_POST["kol"] == 0 ) {
            echo '<center>';
     	       echo '<h3 style="color:red">Неверное количество товара!</h3>';
            echo '</center>';

          } else {    	

    	//Проверка наличия товара в корзине
if(!($query = $link->prepare("SELECT id FROM trash WHERE tovarid=?")))
  {
   echo "Не удалось подготовить запрос: (" . $link->errno . ") " . $link->error;  
  } 
if (!$query->bind_param("i", $_POST['tovar']))
  {
     echo "Не удалось привязать параметры: (" . $query->errno . ") " . $query->error;   
  }
if(!$query->execute())
    {
   echo "Не удалось выполнить запрос: (" . $query->errno . ") " . $query->error;
    }

$query->bind_result($id);
$query->store_result();
$row = $query->num_rows; 
$query->fetch();

     if ($row != 0) {
     	echo '<center>';
     	echo '<h3 style="color:red">Данный товар уже присутствует в корзине!</h3>';
     	echo '</center>';
     } else {

//Добавление в корзину нового товара
//Получение стоимости товара
if(!($query = $link->prepare("SELECT name, price FROM tovar WHERE id=?")))
  {
   echo "Не удалось подготовить запрос: (" . $link->errno . ") " . $link->error;  
  } 
if (!$query->bind_param("i", $_POST['tovar']))
  {
     echo "Не удалось привязать параметры: (" . $query->errno . ") " . $query->error;   
  }
if(!$query->execute())
    {
   echo "Не удалось выполнить запрос: (" . $query->errno . ") " . $query->error;
    }

$query->bind_result($name, $price);
$query->fetch();

//Вставка в корзину нового товара
$link = connect_db();
if ($link->connect_errno) {
    echo "Не удалось подключиться к MySQL: (" . $link->connect_errno . ") " . $link->connect_error;
}
  if (!($query = $link->prepare("INSERT INTO trash(id,tovarid,name,kol,price,summa) VALUES ('',?,?,?,?,?)")))

  {
   echo "Не удалось подготовить запрос: (" . $link->errno . ") " . $link->error;  
  } 

$summa=$_POST['kol']*$price;
if (!$query->bind_param("isiii", $_POST['tovar'], $name, $_POST['kol'], $price, $summa))
  {
     echo "Не удалось привязать параметры: (" . $query->errno . ") " . $query->error;   
  }

if (!$query->execute())
    {
   echo "Не удалось выполнить запрос: (" . $query->errno . ") " . $query->error;
    }

    }
  }
}

// Вывод содержимого корзины

if(!($query = $link->prepare("SELECT id, tovarid, name, kol, price, summa FROM trash")))
  {
   echo "Не удалось подготовить запрос: (" . $link->errno . ") " . $link->error;  
  } 
if(!$query->execute())
    {
   echo "Не удалось выполнить запрос: (" . $query->errno . ") " . $query->error;
    }

$query->bind_result($id, $tovarid, $name, $kol, $price, $summa);

echo "<center><h1>Корзина<h1></center>";
echo "<table class=\"table table-bordered\" border=\"1\" width=\"100%\" bgcolor=\"#FFFFA1\">";
echo '<tr><th style="text-align:center">Товар</th><th style="text-align:center">Количество</th><th style="text-align:center">Цена</th>';
echo '<th style="text-align:center">Сумма</th> <th style="text-align:center">Удалить</th></tr>';

$itogo=0;
$trash=array();

 while ($query->fetch()) {
   $itogo=$itogo+$summa;
   $trash[]=$tovarid;
   echo "<tr align=center bgcolor=\"#FFFFE1\">";
   echo "<td>$name</td><td>$kol</td><td>$price</td>";
   echo "<td>$summa</td>";
   echo '<td><a href="javascript:void(null);" onClick="del('.$id.');">Удалить</a></td>';
   echo "</tr>";
 }
echo "</table>";
echo "</br></br></br>";

//Проверка участия в акциях
$action=0;
if(in_array(1,$trash) & in_array(2,$trash))  { $itogo=$itogo/2; $action=$action+1; }
if(in_array(4,$trash) & !in_array(3,$trash)) { $itogo=$itogo-20; $action=$action+1; }

echo "<h3>Примененные акции: $action</h3>";

echo "<h3>Итого: ".$itogo."</h3></br>";


?>





