<?php
function connect_db()
{
   $host     = "localhost";
   $db       = "Baza2015";
   $user     = "root";
   $password = "babaj4972";
 try {
   $link = new mysqli($host, $user, $password, $db);
   return $link; 

 } catch (Exception $e) {
     echo $e->getMessage();
     return false;
   }

}

?>