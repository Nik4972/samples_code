<?php
session_start();
error_reporting(0);
require "db_connect.tpl";
require("classes/class_main.php");
$object = new main;

$client_id = '1623166174651733'; // Client ID
$client_secret = 'd570e4c1e6fc845551ac7356255820f8'; // Client secret
$redirect_uri = 'http://amicoin.com/login.php'; // Redirect URIs

if(!isset($_GET['code'])) {
$url = 'https://www.facebook.com/dialog/oauth';

$params = array(
    'redirect_uri'  => $redirect_uri,
    'response_type' => 'code',
    'client_id'     => $client_id
);

header('Location: '.$url . '?' . urldecode(http_build_query($params)));
exit;
}

if (isset($_GET['code'])) {
    $result = false;

    $params = array(
        'client_id'     => $client_id,
        'client_secret' => $client_secret,
        'redirect_uri'  => $redirect_uri,
        'code'          => $_GET['code'],
        'redirect'      => 0,
        'fields'        => 'id,name,first_name,last_name,email'  // !Обязательно названия полей писать БЕЗ ПРОБЕЛОВ после запятых т.к. потом преобразуется в URL
    );

    $url = 'https://graph.facebook.com/oauth/access_token';
$tokenInfo = null;
parse_str(file_get_contents($url . '?' . http_build_query($params)), $tokenInfo);

    if (isset($tokenInfo['access_token'])) {
        //$params = array('access_token' => $tokenInfo['access_token']);
        $params['access_token'] = $tokenInfo['access_token'];

        $userInfo = json_decode(file_get_contents('https://graph.facebook.com/me' . '?' . urldecode(http_build_query($params))), true);
        
//        $object->log_info(array('User' => json_encode($userInfo), 'ServiceName' => 'Report'));
        
        if (isset($userInfo['id'])) {
            $userInfo = $userInfo;
            $result = true;
        }
    }

    if ($result) {
		
		$row = $object->db_select("*", "users", "WHERE fb_uid='".$userInfo['id']."'", "", "LIMIT 1");
		if($row[0]['id']>0) {
		
			$_SESSION['user']['id'] = $row[0]['id'];
			$_SESSION['user']['login'] = $row[0]['login'];
			$_SESSION['user']['login_type'] = 'fb';
			$_SESSION['user']['type_uid'] = $row[0]['fb_uid'];
			$_SESSION['user']['fio'] = $row[0]['fio'];
			$_SESSION['user']['name'] = $row[0]['name'];
			$_SESSION['user']['photo'] = (!empty($row[0]['photo'])) ? $row[0]['photo'] : 'avatar.jpg';

			header('Location: /cabinet/'.$row[0]['login']);
			exit;
		}
		else {
			
			$pass = rand(100000, 999999);
			$photo = '';
			//$login = explode('@',$userInfo['email']);
                        $login = $object->GetInTranslit($userInfo['first_name']);
                        
                         if ($login === "")
                             $login = $object->GetInTranslit($userInfo['last_name']);
                         
			$fields = array("login","pass","name","fio","fb_uid","fb","email");
			$values = array("val" => array(
                            	//addslashes($userInfo['first_name']),
				//addslashes($login[0]),
                                addslashes($login),
				addslashes($pass),
				addslashes($userInfo['first_name']),
				addslashes($userInfo['last_name']),
				$userInfo['id'],
			        addslashes('https://www.facebook.com/'.$userInfo['id']),	
				addslashes($userInfo['email'])
			),
			"kind" => array("text","text","text","text","num","text","text"));
			$object->db_insert($fields,$values,"users");
			
			$id = mysql_insert_id();
			
			$_SESSION['user']['id'] = $id;
			//$_SESSION['user']['login'] = $login[0];
                        $_SESSION['user']['login'] = $login;
			$_SESSION['user']['login_type'] = 'fb';
			$_SESSION['user']['type_uid'] = $userInfo['id'];
			$_SESSION['user']['fio'] = $userInfo['name'];
			$_SESSION['user']['neme'] = $userInfo['name'];
			$_SESSION['user']['photo'] = (!empty($photo)) ? $photo : 'avatar.jpg';
			
			//header('Location: /cabinet/'.$login[0]);
                        header('Location: /cabinet/'.$login);
			exit;
			
		}
		
    }

}

?>
