<?php
session_start();
error_reporting(0);

if(isset($_GET['url']) || isset($_GET['code'])) {

$acces = true;

if(isset($_GET['url'])) {

$ip = $_SERVER['REMOTE_ADDR'];

$acces = (md5($ip)==$_GET['url']) ? true:false ;

}

if($acces) {

require "db_connect.tpl";
require("classes/class_main.php");
$object = new main;

require_once 'classes/vk/VkPhpSdk.php';
require_once 'classes/vk/Oauth2Proxy.php';

$oauth2Proxy = new Oauth2Proxy(
    //'4025370', // client id
    '5767351',
    //'YguPUHoYtLoqeMbPNvA2', // client secret
    'CWqC7TkkEwBF5JxW3Psp', // client secret        
    'https://oauth.vk.com/access_token', // access token url
    'https://oauth.vk.com/authorize', // dialog uri
    'code', // response type
    'http://amicoin.com/login_vk.php', // redirect url
    'offline,notify,friends,photos,audio,video,wall' // scope
);

print_r($oauth2Proxy);

if($oauth2Proxy->authorize() === true)
{

        $vkPhpSdk = new VkPhpSdk();
        $vkPhpSdk->setAccessToken($oauth2Proxy->getAccessToken());
        $vkPhpSdk->setUserId($oauth2Proxy->getUserId());


        $result = $vkPhpSdk->api('getProfiles', array(
                'uids' => $vkPhpSdk->getUserId(),
                'fields' => 'uid, first_name, last_name, nickname, screen_name, photo_big',
        ));
        
        //$object->log_info(array('User' => json_encode($result), 'ServiceName' => 'Report'));
       
	    if($result['response'][0]['uid']>0) {
		
	    $row = $object->db_select("*", "users", "WHERE vk_uid='".$result['response'][0]['uid']."'", "", "LIMIT 1");
		if($row[0]['vk_uid']>0) {
		
			$_SESSION['user']['id'] = $row[0]['id'];
			$_SESSION['user']['login'] = $row[0]['login'];
			$_SESSION['user']['login_type'] = 'vk';
			$_SESSION['user']['type_uid'] = $row[0]['vk_uid'];
			$_SESSION['user']['fio'] = $row[0]['fio'];
			$_SESSION['user']['neme'] = $row[0]['neme'];
			$_SESSION['user']['photo'] = (!empty($row[0]['photo'])) ? $row[0]['photo']:'avatar.jpg';

			header('Location: /cabinet/'.$row[0]['login']);
			exit;
		}
		else {
			
			$pass = rand(100000, 999999);
			$photo = '';
			$path = $_SERVER['DOCUMENT_ROOT']."/img/users/225/";
			if(trim($result['response'][0]['photo_big'])!='') {
				$photo = md5(microtime()).".png";
				$file = file_get_contents(stripslashes($result['response'][0]['photo_big']));
				$fp=fopen($path.$photo,"w+");
				fwrite($fp,$file);
				fclose($fp);
			}
		
			$fields = array("login","pass","name","fio","vk_uid","vk","photo");
			$values = array("val" => array(
				addslashes($result['response'][0]['screen_name']),
				addslashes($pass),
				addslashes($result['response'][0]['first_name']),
				addslashes($result['response'][0]['last_name']),
				$result['response'][0]['uid'],
				addslashes('http://vk.com/'.$result['response'][0]['screen_name']),
				$photo
			),
			"kind" => array("text","text","text","text","num","text","text"));
			$object->db_insert($fields,$values,"users");
			
			$id = mysql_insert_id();
			
			$_SESSION['user']['id'] = $id;
			$_SESSION['user']['login'] = $result['response'][0]['screen_name'];
			$_SESSION['user']['login_type'] = 'vk';
			$_SESSION['user']['type_uid'] = $result['response'][0]['uid'];
			$_SESSION['user']['fio'] = $result['response'][0]['last_name'];
			$_SESSION['user']['neme'] = $result['response'][0]['first_name'];
			$_SESSION['user']['photo'] = (!empty($photo)) ? $photo:'avatar.jpg';
			
			header('Location: /cabinet/'.$result['response'][0]['screen_name']);
			exit;
			
		}
		}
		else {
			/*header('Location: /');
			exit;*/
		}
		
        /*

        $result = $vkPhpSdk->api('wall.post', array(
                'owner_id' => $vkPhpSdk->getUserId(),
                'message' => 'Wellcome to vkPhpSdk!',
        ));
        echo 'Wall post response: <br />';
        echo '<pre>';
        print_r($result);
        echo '</pre>';  */      
}
else { 
//header('Location: /');
//exit;
//echo 'error';
}

}
/*
header('Location: /');
exit;*/

}