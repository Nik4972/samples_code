<?php
session_start();
error_reporting(0);
require "db_connect.tpl";
require("classes/class_main.php");
$object = new main;

$client_id = '787215213255-7lfiresss2qi1grh29o5rpjv4u1re81n.apps.googleusercontent.com'; // Client ID
$client_secret = 'ZbMIEFV72zuV55AqeXStXUHu'; // Client secret
$redirect_uri = 'http://amicoin.com/login_g.php'; // Redirect URIs

if(!isset($_GET['code'])) {
$url = 'https://accounts.google.com/o/oauth2/auth';

$params = array(
    'redirect_uri'  => $redirect_uri,
    'response_type' => 'code',
    'client_id'     => $client_id,
    'scope'         => 'https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile'
);

header('Location: '.$url . '?' . urldecode(http_build_query($params)));
exit;
}

if (isset($_GET['code'])) {
    $result = false;

    $params = array(
        'client_id'     => $client_id,
        'client_secret' => $client_secret,
        'redirect_uri'  => $redirect_uri,
        'grant_type'    => 'authorization_code',
        'code'          => $_GET['code']
    );

    $url = 'https://accounts.google.com/o/oauth2/token';

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, urldecode(http_build_query($params)));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($curl);
    curl_close($curl);
    $tokenInfo = json_decode($result, true);

    if (isset($tokenInfo['access_token'])) {
        $params['access_token'] = $tokenInfo['access_token'];

        $userInfo = json_decode(file_get_contents('https://www.googleapis.com/oauth2/v1/userinfo' . '?' . urldecode(http_build_query($params))), true);
        if (isset($userInfo['id'])) {
            $userInfo = $userInfo;
            $result = true;
        }
              $object->log_info(array('User' => json_encode($userInfo), 'ServiceName' => 'Report'));
    }

    if ($result) {
		
		$row = $object->db_select("*", "users", "WHERE google_uid='".$userInfo['id']."'", "", "LIMIT 1");
		if($row[0]['id']>0) {
		
			$_SESSION['user']['id'] = $row[0]['id'];
			$_SESSION['user']['login'] = $row[0]['login'];
			$_SESSION['user']['login_type'] = 'g_plus';
			$_SESSION['user']['type_uid'] = $row[0]['google_uid'];
			$_SESSION['user']['fio'] = $row[0]['fio'];
			$_SESSION['user']['name'] = $row[0]['name'];
			$_SESSION['user']['photo'] = (!empty($row[0]['photo'])) ? $row[0]['photo']:'avatar.jpg';

			header('Location: /cabinet/'.$row[0]['login']);
			exit;
		}
		else {
			
			$pass = rand(100000, 999999);
			$photo = '';
			$login = explode('@',$userInfo['email']);
			$path = $_SERVER['DOCUMENT_ROOT']."/img/users/225/";
			if(trim($userInfo['picture'])!='') {
				$photo = md5(microtime()).".jpg";
				$file = file_get_contents(stripslashes($userInfo['picture']));
				$fp=fopen($path.$photo,"w+");
				fwrite($fp,$file);
				fclose($fp);
			}
			
			$fields = array("login","pass","name","fio","google_uid","g_plus","photo","email","online");
			$values = array("val" => array(
				addslashes($login[0]),
				addslashes($pass),
				addslashes($userInfo['family_name']),
				addslashes($userInfo['given_name']),
				$userInfo['id'],
				addslashes('https://plus.google.com/'.$userInfo['id'].'/posts'),
				$photo,
				$userInfo['email'],
                                1
			),
			"kind" => array("text","text","text","text","num","text","text","text","num"));
			$object->db_insert($fields,$values,"users");
			
			$id = mysql_insert_id();
			
			$_SESSION['user']['id'] = $id;
			$_SESSION['user']['login'] = $login[0];
			$_SESSION['user']['login_type'] = 'g_plus';
			$_SESSION['user']['type_uid'] = $userInfo['id'];
			$_SESSION['user']['fio'] = $userInfo['family_name'];
			$_SESSION['user']['neme'] = $userInfo['given_name'];
			$_SESSION['user']['photo'] = (!empty($photo)) ? $photo:'avatar.jpg';
			
			header('Location: /cabinet/'.$login[0]);
			exit;
			
		}
		
    }

}

?>
