<?php
    require_once '../../sess.inc';
    require_once dirname(dirname(dirname(__FILE__))) . '/lib/mpdf/mpdf.php';


$ret = new stdClass();
$ret->status = 'Wrong params';

try {
    $oper       = isset($_POST['oper'])        ? filter_input(INPUT_POST,'oper',  FILTER_SANITIZE_STRING)                 : '';
    $id         = isset($_POST['id'])          ? intval(filter_input(INPUT_POST,'id',    FILTER_SANITIZE_NUMBER_INT))     : 0;
    $param      = isset($_POST['param'])       ? intval(filter_input(INPUT_POST,'param', FILTER_SANITIZE_NUMBER_INT))     : 0;
    $nom_nakl   = isset($_POST['nom_nakl'])    ? intval(filter_input(INPUT_POST,'nom_nakl', FILTER_SANITIZE_NUMBER_INT))  : 0;
    $nom_avto   = isset($_POST['nom_avto'])    ? filter_input(INPUT_POST,'nom_avto',  FILTER_SANITIZE_STRING)         : '';    
    $otpravitel = isset($_POST['otpravitel'])  ? filter_input(INPUT_POST,'otpravitel',  FILTER_SANITIZE_STRING)         : '';    
    $poluchatel = isset($_POST['poluchatel'])  ? filter_input(INPUT_POST,'poluchatel',  FILTER_SANITIZE_STRING)         : '';    
    $plat       = isset($_POST['plat'])        ? filter_input(INPUT_POST,'plat',  FILTER_SANITIZE_STRING)         : '';    
    $perevoz    = isset($_POST['perevoz'])     ? filter_input(INPUT_POST,'perevoz',  FILTER_SANITIZE_STRING)         : '';    
    $gruz       = isset($_POST['gruz'])        ? filter_input(INPUT_POST,'gruz',  FILTER_SANITIZE_STRING)         : '';        
    $brutto     = isset($_POST['brutto'])      ? intval(filter_input(INPUT_POST,'brutto', FILTER_SANITIZE_NUMBER_INT))  : 0;
    $tara       = isset($_POST['tara'])        ? intval(filter_input(INPUT_POST,'tara', FILTER_SANITIZE_NUMBER_INT))  : 0;    
    $netto      = isset($_POST['netto'])       ? intval(filter_input(INPUT_POST,'netto', FILTER_SANITIZE_NUMBER_INT))  : 0;    
    $dat_priem  = isset($_POST['dat_priem'])   ? filter_input(INPUT_POST,'dat_priem',  FILTER_SANITIZE_STRING)         : '';    
    $priemshik  = isset($_POST['priemshik'])   ? filter_input(INPUT_POST,'priemshik',  FILTER_SANITIZE_STRING)         : '';    
    $dat_otprav = isset($_POST['dat_otprav'])  ? filter_input(INPUT_POST,'dat_otprav',  FILTER_SANITIZE_STRING)         : '';    
    $otpravshik = isset($_POST['otpravshik'])  ? filter_input(INPUT_POST,'otpravshik',  FILTER_SANITIZE_STRING)         : '';        
    $nom_pricep = isset($_POST['nom_pricep'])  ? filter_input(INPUT_POST,'nom_pricep',  FILTER_SANITIZE_STRING)         : '';            
    $brutto_pricep = isset($_POST['brutto_pricep']) ? intval(filter_input(INPUT_POST,'brutto_pricep', FILTER_SANITIZE_NUMBER_INT))  : 0;
    $tara_pricep   = isset($_POST['tara_pricep'])   ? intval(filter_input(INPUT_POST,'tara_pricep', FILTER_SANITIZE_NUMBER_INT))  : 0;    
    $netto_pricep  = isset($_POST['netto_pricep'])  ? intval(filter_input(INPUT_POST,'netto_pricep', FILTER_SANITIZE_NUMBER_INT))  : 0;    

    $beg = isset($_POST['beg'])  ? filter_input(INPUT_POST,'beg',  FILTER_SANITIZE_STRING)         : '';        
    $end = isset($_POST['end'])  ? filter_input(INPUT_POST,'end',  FILTER_SANITIZE_STRING)         : '';            
    
    $operation = isset($_POST['operation'])   ? intval(filter_input(INPUT_POST,'operation', FILTER_SANITIZE_NUMBER_INT)) : 0;
   
    $dat_priem = $dat_priem.':00';
    $dat_priem = date('Y-m-d H:i:s', strtotime($dat_priem));

    $dat_otprav = $dat_otprav.':00';
    $dat_otprav = date('Y-m-d H:i:s', strtotime($dat_otprav));
    
    $beg = date('Y-m-d H:i:s', strtotime($beg));
    $end = date('Y-m-d H:i:s', strtotime($end));
    
    switch($oper) {
        case 'del' :
            $query='DELETE FROM `scales_ttn` WHERE `id`='.$id;
            $q=$DB->query($query);
            $ret->status = $q ? 'ok' : $q;            
            break;
        
        case 'unlink' :
            $dend = "2999-12-31 23:59:59" ;
            $query='UPDATE `gps_rfid_owners` SET `cdo_end` = now() WHERE `cdo_card`='.$id.' AND `cdo_end`="'.$dend.'"';
            $q=$DB->query($query);
            $ret->status = $q ? 'ok' : $q;            
            break;

        case 'link' :
          
             $q = $DB->query('INSERT INTO scales_ttn (nom_nakl, nom_avto, otpravitel, poluchatel,'
               . ' plat, perevoz, gruz, brutto, tara, netto, dat_priem, priemshik, dat_otprav,'
               . ' otpravshik, nom_pricep, brutto_pricep, tara_pricep, netto_pricep, operation, created_at, updated_at)'
               . ' VALUES ("'.$nom_nakl.'","'.$nom_avto.'","'.$otpravitel.'","'.$poluchatel.'","'
               .$plat.'","'.$perevoz.'","'.$gruz.'","'.$brutto.'","'.$tara.'","'.$netto.'","'
               .$dat_priem.'","'.$priemshik.'","'.$dat_otprav.'","'.$otpravshik.'","'.$nom_pricep.'","'
               .$brutto_pricep.'","'.$tara_pricep.'","'.$netto_pricep.'",'.$operation.',now(),now())');

            $ret->status = $q ? 'ok' : $q;            
            break;
                
        case 'edit':
             $ret->status = $r ? $r : 'ok';
            break;
        
        case 'pdf':  

                 $css = '<style>
                        body { font-family: serif; font-size:9pt; }
                        .top { text-align:right; float:right; }
                        .hdr { text-align:center; }
                        .hdr .rep_h { font-weight:bold; font-size:12pt; }
                        .hdr .rep_t { text-align:left; font-weight:bold; font-size:9pt;}
                        .hdr .rep_m { font-style: italic; text-align:left; font-size:6pt; }
                        .txt { text-indent:30px; }
                        .hgl { font-weight:bold; font-style: italic; }
                        ol { margin:0; padding:0 0 3px; }
                        .items {
                            border-collapse: collapse;
                            width:100%;
                        }
                        .items td { text-align:center; vertical-align:middle; }
                        .items th { text-align:center; vertical-align:middle; background:#ddd; }
                        .items .lft { text-align:left; }
                        .items .rht { text-align:right; }
                        .logo { text-align: center; }

                        </style>';

$html = '<div class="hdr">
<div class="rep_t">Додаток 7</div>
<div class="rep_t">до Правил перевезення вантажiв</div>
<div class="rep_t">автомобiльним транспортом в Українi</div>
<div class="rep_t">форма № 1-ТН</div>

                              <div class="rep_h">ТОВАРНО-ТРАНСПОРТНА НАКЛАДНА</div><br>
                              <div class="rep_h">№____________вiд '.date("d.m.Y").' р.</div><br><br>

 <div class="rep_t">Автомобiль____________________________________________________Причiп/напiвпричiп_______________________________________________Вид перевезень__________________________________</div>
  <div class="rep_m"><pre>                            (марка, модель, тип, номер)                                                           (марка, модель, тип, номер)</pre></div>
 
  <div class="rep_t">Автомобiльный перевiзник___________________________________________________________________________________________Водiй___________________________________________________________</div>
  <div class="rep_m"><pre>                                                                     (найменування/П.I.Б)                                                                     (П.I.Б., номер посвiдчення водiя)</pre></div>
 
 <div class="rep_t">Замовник__________________________________________________________________________________________________________________________________________________________________________________</div>
  <div class="rep_m"><pre>                                                                                    (найменування/П.I.Б)       </pre></div>
 
 <div class="rep_t">Вантажовiдправник______________________________________________________________________________________________________________________________________________________________________</div>
  <div class="rep_m"><pre>                                                                                    (повне найменування, мiсце знаходження/П.I.Б., мiсце проживання)</pre></div>
 
 <div class="rep_t">Вантажоодержувач_______________________________________________________________________________________________________________________________________________________________________</div>
  <div class="rep_m"><pre>                                                                                    (повне найменування, мiсце знаходження/П.I.Б., мiсце проживання)</pre></div>
 
<div class="rep_t">Пункт навантаження_____________________________________________________________________________Пункт розвантаження_____________________________________________________________</div>
  <div class="rep_m"><pre>                                                                     (мiсце знаходження)                                                                     (мiсце знаходження)</pre></div>

<div class="rep_t">Переадресування вантажу______________________________________________________________________________________________________________________________________________________________</div>
  <div class="rep_m"><pre>                                        (найменування, мiсце знаходження/П.I.Б., мiсце проживання нового вантажоодержувача; П.I.Б., посада та пiдпис вiдповiдальноi особи)</pre></div>
  
<div class="rep_t">Вiдпуск за довiренiстю вантажоодержувача: серiя________________№___________________вiд_______________________виданою________________________________________________________</div><br>  

<div class="rep_t">Вантаж наданий для перевезення у станi, що_____________________правилам перевезень вiдповiдних вантажiв, номер пломбы (за наявностi) __________________________</div>  
<div class="rep_m"><pre>                                                             (вiдповiдае/не вiдповiдае)</pre></div>

<div class="rep_t">Кiлькiсть мiсць________________________________________, масса брутто____________________________________________, отримав водiй/експедитор _____________________________________</div>  
<div class="rep_m"><pre>                                     (словами)                                                    (словами)</pre></div>

<div class="rep_t">Бухгалтер (вiдповiдальна особа вантажовiдправника)_______________________________________________________, Вiдпуск дозволив _______________________________________________</div>  
<div class="rep_m"><pre>                                                                                  (П.I.Б., посада, пiдпис)                                               (П.I.Б., посада, пiдпис, печатка)</pre></div>

<div class="rep_t">Усього вiдпущено на загальну суму____________________________________________________________________________________, у т.ч. ПДВ_________________________________________________</div>  
<div class="rep_m"><pre>                                                           (словами, з урахованнням ПДВ)</pre></div>

<div class="rep_t">Супровiднi документи на вантаж_______________________________________________________________________________________________________________________________________________________</div><br>   

<div class="rep_t">Транспортнi послуги, якi надаються автомобiльним перевiзником_______________________________________________________________________________________________________________</div><br><br><br><br><br><br>

<div class="logo"><img src="/realagro/gps/img/logo_firm.png"/></div><br>
<div class="rep_h">ОТЧЕТ №_____</div><br>
<div class="rep_h">о движении зерновых и масличных культур</div><br>
<div class="rep_h">за '.date("d.m.Y").' г.</div><br>
    ';



                $tbl_begin = '<table class="items" width="100%" cellpadding="5" border="1"><thead><tr>
                            <th style="width:7mm">№ п/п</th>
                            <th>Наименование</th>
                            <th style="width:10mm">Ост. на нач. дня, кг</th>
                            <th style="width:8mm">Приход, кг</th>
                            <th style="width:15mm">Расход, кг</th>
                            <th style="width:27mm">Остаток, кг</th>
                            </tr></thead>';

        global $DB;
        $body = array();
        $n=1;

      //  $DB->query('SET NAMES utf8 COLLATE utf8_general_ci');
       
 $rows_prihod = $DB->select("SELECT SUM(netto) as prihod FROM scales_ttn WHERE operation = 1 AND created_at >='$beg' AND created_at <='$end'");
      if($rows_prihod === FALSE) throw new Exception($DB->error);
 $rows_rashod = $DB->select("SELECT SUM(netto) as rashod FROM scales_ttn WHERE operation = 0 AND created_at >='$beg' AND created_at <='$end'");
      if($rows_rashod === FALSE) throw new Exception($DB->error);

                    $row2 = "<td class='lft'>".$n."</td>
                        <td class='lft'></td>
                        <td class='lft'></td>
                        <td class='lft'>".$rows_prihod[0]['prihod']."</td>
                        <td class='lft'>".$rows_rashod[0]['rashod']."</td>
                        <td class='lft'></td>";
                    $body[] = $row2;
 
                    $mpdf = null;

                    //              mode  FMT   sz fnt  L   R   T  B HD FT  OR
                    $mpdf = new mPDF('s', 'A4-L', 10, '', 10, 10, 5, 3, 0, 0, 'L');
                    

                    $mpdf->useSubstitutions = false;

                    $mpdf->SetTitle("Отчет");

                    $mpdf->SetCreator('mPDF ' . mPDF_VERSION);

                    $mpdf->SetDisplayMode('fullpage');

                    $mpdf->WriteHTML($css);

                    $logo = '<div class="logo"><img src="/realagro/gps/img/logo_firm.png"/></div><br><br>';
                    
              //      $mpdf->WriteHTML($logo);

                    $mpdf->WriteHTML($html . $tbl_begin . '<tbody><tr>' . implode('</tr><tr>', $body) . '</tr></tbody></table>');

                $u=1;
                $FileName = sprintf("completion_report_%u.pdf", $u);

                $mpdf->Output($FileName, 'I');
                $out = $mpdf->buffer;
                if(!empty($out)) {
                    $key = $mpdf->UniqueId;
                }

               break;
        
        default:
            $ret->status = "Invalid oper $oper";
            break;
    }
}
catch (Exception $e) {
    $ret->status = $e->getMessage();
}


header('Content-type: application/json; charset=utf-8');
echo json_encode($ret);

