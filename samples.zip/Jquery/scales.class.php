<?php
require_once PATH_INC . "/sqlgenerator.class.php";
/**
* Класс для учета весовых
*/
class Scales {
    public $rowsTotal = 0;
    public $pages     = 0;
    public $pagesize  = 20;
    const TABLE        = "spr_scales";
    const TABLE_TYPE   = "spr_scale_types";

    const FLAG_PC           = 0;
    const FLAG_CABLE        = 1;
    const FLAG_SOFT         = 2;
    const FLAG_LINK         = 3;
    const FLAG_LINK_PROCESS = 4;

    static public $Flags = array(
        self::FLAG_PC           => array("Есть ПК",'','laptop',''),
        self::FLAG_CABLE        => array("Есть кабель",'','usb',''),
        self::FLAG_SOFT         => array("Есть ПО для весов",'','floppy-o',''),
        self::FLAG_LINK         => array("Есть канал связи","Нет канала связи",'check-square-o','times-circle'),
        self::FLAG_LINK_PROCESS => array("Налаживается канал связи",'','spinner','')
    );
    static public $Table = array(
        SqlGenerator::STRUCT_TABLE_NAME   => self::TABLE,
        SqlGenerator::STRUCT_FIELDS => array(
            'id'          => array(
                           SqlGenerator::STRUCT_TYPE    => SqlGenerator::FIELD_INT,
                           SqlGenerator::FIELD_UNSIGNED => true,
                           SqlGenerator::FIELD_IS_NULL  => false,
                           SqlGenerator::FIELD_COUNTER  => true
                          ),
            'type_id'     => array(
                           SqlGenerator::STRUCT_TYPE    => SqlGenerator::FIELD_INT,
                           SqlGenerator::FIELD_UNSIGNED => true,
                           SqlGenerator::FIELD_IS_NULL  => false
                          ),
            'loc_point_id' => array(
                           SqlGenerator::STRUCT_TYPE    => SqlGenerator::FIELD_INT,
                           SqlGenerator::FIELD_UNSIGNED => true,
                           SqlGenerator::FIELD_IS_NULL  => false
                          ),
            'flags'       => array(
                           SqlGenerator::STRUCT_TYPE    => SqlGenerator::FIELD_INT,
                           SqlGenerator::FIELD_UNSIGNED => true,
                           SqlGenerator::FIELD_IS_NULL  => false
                          )
            ),
        SqlGenerator::STRUCT_INDEXES  => array(
            SqlGenerator::INDEX_PRIMARY => array(
                SqlGenerator::STRUCT_TYPE   => SqlGenerator::INDEX_PRIMARY,
                SqlGenerator::STRUCT_FIELDS => array("id" => 4)
            ),
            'type_id'                 => array(
                SqlGenerator::STRUCT_TYPE    => SqlGenerator::INDEX_INDEX,
                SqlGenerator::STRUCT_FIELDS  => array('type_id' => 4),
                SqlGenerator::STRUCT_FOREIGN => array(
                    SqlGenerator::STRUCT_TABLE_NAME => self::TABLE_TYPE,
                    SqlGenerator::STRUCT_FIELDS     => array('type_id' => 'id')
                )
            ),
            'loc_point_id'                 => array(
                SqlGenerator::STRUCT_TYPE    => SqlGenerator::INDEX_INDEX,
                SqlGenerator::STRUCT_FIELDS  => array('loc_point_id' => 4),
                SqlGenerator::STRUCT_FOREIGN => array(
                    SqlGenerator::STRUCT_TABLE_NAME => 'loc_points',
                    SqlGenerator::STRUCT_FIELDS     => array('loc_point_id' => 'p_id')
                )
            ),
        )
    );

    const FLAG_TYPE_PORT = 0;

    static public $FlagsType = array(
        self::FLAG_TYPE_PORT => "Есть порт для ПК"
    );

    static public $TableType = array(
        SqlGenerator::STRUCT_TABLE_NAME   => self::TABLE_TYPE,
        SqlGenerator::STRUCT_FIELDS => array(
            'id'          => array(
                           SqlGenerator::STRUCT_TYPE    => SqlGenerator::FIELD_INT,
                           SqlGenerator::FIELD_UNSIGNED => true,
                           SqlGenerator::FIELD_IS_NULL  => false,
                           SqlGenerator::FIELD_COUNTER  => true
                          ),
            'name_su'     => array(
                           SqlGenerator::STRUCT_TYPE    => SqlGenerator::FIELD_VARCHAR,
                           SqlGenerator::STRUCT_SYZE    => 255,
                           SqlGenerator::FIELD_IS_NULL  => true
                          ),
            'name_po_loc' => array(
                           SqlGenerator::STRUCT_TYPE    => SqlGenerator::FIELD_VARCHAR,
                           SqlGenerator::STRUCT_SYZE    => 255,
                           SqlGenerator::FIELD_IS_NULL  => true
                          ),
            'name_po_1c'  => array(
                           SqlGenerator::STRUCT_TYPE    => SqlGenerator::FIELD_VARCHAR,
                           SqlGenerator::STRUCT_SYZE    => 255,
                           SqlGenerator::FIELD_IS_NULL  => true
                          ),
            'flags'       => array(
                           SqlGenerator::STRUCT_TYPE    => SqlGenerator::FIELD_INT,
                           SqlGenerator::FIELD_UNSIGNED => true,
                           SqlGenerator::FIELD_IS_NULL  => false
                          )
            ),
        SqlGenerator::STRUCT_INDEXES  => array(
            SqlGenerator::INDEX_PRIMARY => array(
                SqlGenerator::STRUCT_TYPE   => SqlGenerator::INDEX_PRIMARY,
                SqlGenerator::STRUCT_FIELDS => array("id" => 4)
            )
        )
    );
    const FIELD_KEY = "id";
    private $DB = null;
    public  $query = "";
    public  $lastError = "";

    public function __construct($db, $pagesize = null) {
        $this->DB = $db;
        if (!is_null($pagesize) && (int)$pagesize > 0) $this->pagesize = (int)$pagesize;
    }

    public function getById($id,$ext = false) {
        if (!$id) return false;
        $row = $this->DB->select("SELECT * FROM `" . self::TABLE . "` WHERE " . self::FIELD_KEY . "=" . $id);
        $ret = array();
        if (!$row) return false;
        $row = $row[0];
        if ($ext) {
            $flags = (int)$row['flags'];
            $flg = array();
            foreach(self::$Flags as $shift => $vals) {
                $flg[$shift] = $flags & (1<<$shift) ? 1 : 0;
            }
            $row['flags'] = $flg;
            $rowP = $this->DB->select("SELECT p_id,p_obj,p_type,p_name FROM loc_points WHERE p_id=" . $row['loc_point_id']);
            if ($rowP) {
                $point = $rowP[0];
                $row['point'] = $point;
                $rowO = $this->DB->select("SELECT o_id,o_firm,o_type,o_name FROM loc_objects WHERE o_id=" . $point['p_obj']);
                if ($rowO) {
                    $row['object'] = $rowO[0];
                }
            }
        }
        return $row;
    }

    public function save($row) {
        $oSqlGen = new SqlGenerator(self::$Table);
        $items = array();
        if (isset($row[self::FIELD_KEY]) && (int)$row[self::FIELD_KEY]) {
            $old = $this->getById($row[self::FIELD_KEY]);
            if (!$old) return false;

            foreach ($row as $field => $val) $old[$field] = $val;
            $id = (int)$row[self::FIELD_KEY];
            $condition = "`" . self::FIELD_KEY . "`=" . $id;
            unset($old[self::FIELD_KEY]);
            $this->query = $oSqlGen->renderUpdate($old, $condition);
            $ret = $this->DB->query($this->query);
        } else {  // INSERT
            $this->query = $oSqlGen->renderInsert($row, false, false);
            $ret = $this->DB->query($this->query);
            if ($ret) $ret = $this->DB->lastInsertId();
        }
        if (!$ret) {
            $this->lastError = "Save error; SQL='".$this->query."'";
            return false;
        }
        return $ret;
    }

    public function deleteById($id) {
        $id = (int)$id;
        if (!$id) return false;

        return $this->DB->query("DELETE FROM `" . self::TABLE . "` WHERE `" . self::FIELD_KEY ."`=" . $id);
    }

    /**
    * Преобразуем полученное целое значение в ассоц.массив со значениями {true|false}
    *
    * @param array $flags
    * @param int $value
    * @return array : {shift => true|false, shift => true|false, ... }
    */
    public function flagToArray($flags, $value) {
        $ret = array();
        foreach ($flags as $shift => $name) {
            $ret[$shift] = ($value | (1<<$shift)) >0 ? true : false;
        }
        return $ret;
    }

    public function getList($params) {
        $aWhere = array();
        $aJoin   = array();
        $aFields = array('`' . self::TABLE . '`.*');

        foreach ($params as $key => $val) {
            if (in_array($key, array_keys(self::$Table[SqlGenerator::STRUCT_FIELDS]))) {
                switch($key) {
                    case 'flags' :
                        if (is_numeric($val)) {
                            $aWhere[] = '(' . self::TABLE . ".`$key` & $val) > 0";
                        } elseif (is_array($val)) {
                            foreach ($val as $shift => $isOn) {
                                $aWhere[] = '(`' . self::TABLE . '`.`flags` & 1<<' . $shift . ')' . ($isOn ? '>':'=') . '0';
                            }
                        }
                        break;

                    default:
                        $aWhere[] = self::TABLE . ".`$key` = $val";
                        break;
                }
            } elseif ($key == 'FILEDS' && is_array($val)) {
                $aFields = array();
                foreach ($params['FILEDS'] as $field) {
                    if (isset(self::$Table[SqlGenerator::STRUCT_FIELDS][$field])) {
                        $aFields[] = '`' . self::TABLE . '`.`' . $field . '`';
                    }
                }
            } elseif ($key == "FOREIGN" && is_array($val)) {
                foreach($val as $foreignKey => $foreignFields) {
                    if (isset(self::$Table[SqlGenerator::STRUCT_INDEXES][$foreignKey])) {
                        $tableStruct = self::$Table[SqlGenerator::STRUCT_INDEXES][$foreignKey];
                        $tableJoin   = $tableStruct[SqlGenerator::STRUCT_FOREIGN][SqlGenerator::STRUCT_TABLE_NAME];
                        $tableFields = $tableStruct[SqlGenerator::STRUCT_FOREIGN][SqlGenerator::STRUCT_FIELDS];
                        $tableOn = array();
                        foreach($tableFields as $field => $fieldJoin) {
                            $tableOn[] = "`" . self::TABLE . "`.`" . $field . "`=`" . $tableJoin . "`.`" . $fieldJoin . "`";
                        }
                        $aJoin[] = " LEFT JOIN `" . $tableJoin . "` ON " . implode(" AND ", $tableOn);

                        foreach ($foreignFields as $field => $alias) {
                            $aFields[] = "`" . $tableJoin . "`.`" . $field . "` as " . $alias;
                        }
                    }
                }
            } elseif ($key == "WHERE") {
                $aWhere = array_merge($aWhere, $val);
            }
        }
        if (isset($params["FOREIGN"]['loc_point_id']) && isset($params["objects"])) {
            $aJoin[] = " LEFT JOIN `loc_point_types` ON `loc_points`.`p_type`=`loc_point_types`.pt_id";
            $aFields[] = "`loc_point_types`.`pt_name`";
            $aJoin[] = " LEFT JOIN `loc_objects` ON `loc_points`.`p_obj`=`loc_objects`.`o_id`";
            foreach ($params["objects"] as $field => $alias) {
                $aFields[] = "`loc_objects`.`" . $field . "` as " . $alias;
            }
            $aJoin[] = " LEFT JOIN `loc_city` ON `loc_objects`.`o_city`=`loc_city`.`c_id`";
            $aFields[] = "`loc_city`.`c_name`";
        }

        $this->query = "SELECT " . (isset($params["count_rows"]) ? " SQL_CALC_FOUND_ROWS " : "") .
                ( !$aFields ? "*" : implode(",", $aFields) ) .
                " FROM `" . self::TABLE . "`" .
                ($aJoin  ? implode(" ", $aJoin) : "") .
                ($aWhere ? " WHERE " . implode(" AND ", $aWhere) : "") .
                (isset($params["ORDER BY"]) && !empty($params["ORDER BY"]) ? " ORDER BY " . $params["ORDER BY"] : "") .
                (isset($params["LIMIT"]) ? " LIMIT " . $params["LIMIT"] : "")
        ;

        $rows = $this->DB->select($this->query);
        if ($rows) {
            if (isset($params["count_rows"])) {
                $totalRows       = $this->DB->select("SELECT FOUND_ROWS() as `count`");
                $this->rowsTotal = $totalRows[0]["count"];
                $this->pages     = ceil($this->rowsTotal / $this->pagesize);
            }
            return $rows;
        }

        return false;
    }

    public function saveType($row) {
        $oSqlGen = new SqlGenerator(self::$TableType);
        $items = array();
        if (isset($row[self::FIELD_KEY]) && (int)$row[self::FIELD_KEY]) {
            $old = $this->getById($row[self::FIELD_KEY]);
            if (!$old) return false;

            foreach ($row as $field => $val) $old[$field] = $val;
            $id = (int)$row[self::FIELD_KEY];
            $condition = "`" . self::FIELD_KEY . "`=" . $id;
            unset($old[self::FIELD_KEY]);
            $this->query = $oSqlGen->renderUpdate($old, $condition);
            $ret = $this->DB->query($this->query);
        } else {  // INSERT
            $this->query = $oSqlGen->renderInsert($row, false, false);
            $ret = $this->DB->query($this->query);
            $id = $this->DB->lastInsertId();
            if ($ret) $ret = $id;
        }
        if(!$ret) {
            $this->lastError = "Save error; SQL='".$this->query."'";
            return false;
        }

        return $ret;
    }

    public function getTypes() {
        $rows = $this->DB->select("SELECT * FROM `" . self::TABLE_TYPE . "`");
        if (!$rows) return false;
        $ret = array();
        foreach ($rows as $row) {
            $ret[$row['id']] = $row;
        }
        return $ret;
    }
}