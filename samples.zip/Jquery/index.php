<?php
    $canEdit = $guser->HasRight(75); // Analitic GPS
    $isAdmin = $guser->HasRight(1);

    //require_once PATH_INC . '/rfid_cards.class.php';
    $s_id = isset($_GET['id']) ? filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT) : 0;

    $flg = array();
    foreach(OutService::$Flags as $f => $o) {
        // { f:FLAG, t:'TEXT', i:'FA-ICON', s:STYLE }
        $flg[] = "f:$f,t:'" . iconv('utf-8', 'windows-1251', $o[0]) . "',i:'" . $o[1] . "',s:" . $o[2];
    }

    $grps = array();
    $rows = $DB->select("SELECT * FROM spr_firms_group ORDER BY g_name");
    foreach($rows as $row) {
        $grps[] = '{i:' . $row['g_id'] . ', n:"' . iconv('utf-8', 'windows-1251', $row['g_name']) . '"}';
    }

    $flt = array('gps=0');
    //$flt = array();
    //if(!$guser->FirmsAll) {
      //  $flt[] = 'id IN(' . implode(',', $guser->Firms) . ')';
    //}
    $serviceGroups = array();
    foreach(CFirm::getList($flt, 'name') as $grp) {
        $serviceGroups[] = $grp->Id . ':' . iconv('utf-8', 'windows-1251', str_replace("'", "\\'", $grp->Name));
    }
?>
<style>
.ul_param {
    list-style: none;
    margin: 2px 0 0;
    padding: 0;
}
.ul_param li {
    display: inline-block;
    margin: 0 4px 0 0;
    width: 1em;
}
.ShowHelp {
    position: absolute;
    top: 50%;
    width: 19px;
    margin: -8px 0 0 0;
    padding: 1px;
    height: 18px;
    right: 2px;
    font-size: 1.5em;
}
.ShowHelp i {
    margin: 2px 2px;
}

#dlg_order {display: none}

#dv_help p { color:inherit; width:auto; left:0; }
.sub { float:right; color:navy; font-size:smaller; }
</style>
<br>

<center>
<div id="link_mode">
  <input type='radio' id='link' name="lnk" checked><label for='link' title='�������� � �������� �������'><i class='fa fa-thumbs-up'> </i>&nbsp; ������</label>
  <button role="button" id="add_prihod" name="add_prihod"><i class="fa fa-plus"> </i></button>&nbsp;&nbsp;&nbsp;
  <input type='radio' id='unlink' name="lnk" > <label for='unlink' title='�������� � �������� �������'><i class='fa fa-thumbs-down'> </i>&nbsp; ������</label>
  <button role="button" id="add_rashod" name="add_rashod"><i class="fa fa-plus"> </i></button>
</div>


<label for="start">�</label>&nbsp;<input type="text" class="tbl_ok" id="start" name="start" value="">&nbsp;&nbsp;
<label for="end">��</label>&nbsp;<input type="text" class="tbl_ok" id="end" name="end" value="">&nbsp;&nbsp;
<button role="button" id="snd">��������</button>

<div>
    <table id="list"></table>
    <div id="pager"></div>
</div>
</center>

<div id="dlg_order" oid=0>
	<table class="tbl_frm">
                
                <tr><td>� ��������� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="nom_nakl" name="nom_nakl" value=""></td></tr>

                <tr><td>� ���� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="nom_avto" name="nom_avto" value=""></td>
                <td>������ </td><td colspan="2">
                <input type="text" class="tbl_ok" id="brutto" name="pricep" value="" size="10"></td>
                <td>���� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="tara" name="tara" value="" size="10"></td>
                <td>����� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="netto" name="netto" value="" size="10"></td>
               
                </tr>
                
                <tr><td>����������� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="otpravitel" name="otpravitel" value=""></td></tr>

                <tr><td>���������� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="poluchatel" name="poluchatel" value=""></td></tr>
                
                <tr><td>���������� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="plat" name="plat" value=""></td></tr>

                <tr><td>���������� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="perevoz" name="perevoz" value=""></td></tr>
                
                <tr><td>������������ ����� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="gruz" name="gruz" value=""></td></tr>
                
                <tr><td>����/����� ������� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="dat_priem" name="dat_priem" value=""></td>
                <td>�������� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="priemshik" name="priemshik" value=""></td>                
                </tr>
                
                <tr><td>����/����� �������� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="dat_otprav" name="dat_otprav" value=""></td>
                <td>������������ </td><td colspan="2">
                <input type="text" class="tbl_ok" id="otpravshik" name="otpravshik" value=""></td>
                </tr>

                <tr><td>����� ������� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="nom_pricep" name="nom_pricep" value=""></td>
                <td>������ </td><td colspan="2">
                <input type="text" class="tbl_ok" id="brutto_pricep" name="brutto_pricep" value="" size="10"></td>
                <td>���� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="tara_pricep" name="tara_pricep" value="" size="10"></td>
                <td>����� </td><td colspan="2">
                <input type="text" class="tbl_ok" id="netto_pricep" name="netto_pricep" value="" size="10"></td>

                </tr>
                
        </table>
</div>

<div id="dv_help" style="display:none">
    <p>������� ��� �� ��������</p>
</div>

<form id="makePdf" action="gps/scripts/scales_action.php" method="POST" target="_blank" style="display:none;">
<input type="hidden" name="oper" value="pdf"/>
<input type="hidden" id= "begin"  name="beg" value=""/>
<input type="hidden" id= "endend" name="end" value=""/>
</form>

<script language="JavaScript">
var canEdit = <?=$canEdit ? 'true' : 'false' ?>,
    isAdmin = <?=$isAdmin ? 'true' : 'false' ?>,
    dir     = '<?=$fl ?>/scripts',
    iInit   = <?=$s_id ?>,
    aFlags  = [{<?=implode('},{', $flg) ?>}],
    aFrmGrp = [<?=implode(',', $grps); ?>],
    sSrvGrp = '<?=implode(';', $serviceGroups) ?>',
    iDefGrp = <?=OutServiceGroup::DEFAULT_GROUP ?>;
</script>

<script type="text/javascript" src="/realagro/js/moment.js"></script>
<script type="text/javascript" src="<?=$fl . '/' . $action . '.js?nd=' . time() ?>"></script>
