var $Grid    = null,
    $Help    = null,
    $DlgLdr  = null,

    regHex   = /^[0-9a-fA-F]{1,15}$/,
    regDt = /^(\d\d)\-(\d\d)\-(\d{4})\s(\d\d:\d\d)$/,
    regPrice = /^(\d+)([\.\,](\d{1,2}))*$/;

var parEdit  = {
    closeAfterEdit  : true,
    closeAfterAdd   : true,
    editData        : { context:'card' },
    beforeSubmit    : checkCard,
    beforeShowForm  : initCardForm,
    afterSubmit     : afterSubmit,
    viewPagerButtons: false
};

var parEditHist  = {
    closeAfterEdit  : true,
    closeAfterAdd   : true,
    editData        : { context:'hist' },
    beforeShowForm  : initHistoryForm,
    afterSubmit     : afterSubmit,
    viewPagerButtons: false
};

var mm_event = null;

$('#link_mode').buttonset();
$('#link_mode input').change(changeLink);
$('#add_prihod').prop('disabled', false);
$('#add_rashod').prop('disabled', true);
$('#link_mode').buttonset('refresh');

  function changeLink() {
    var pd   = $Grid.jqGrid('getGridParam', 'postData'),
        link = $('#link').prop('checked') ? 1 : 0;

      if (pd.link == 1){
$('#add_prihod').prop('disabled', true);
$('#add_rashod').prop('disabled', false);
$('#link_mode').buttonset('refresh');
$Grid.jqGrid('setLabel', 'owner', '����������');
    
} else {
$('#add_prihod').prop('disabled', false);
$('#add_rashod').prop('disabled', true);
$('#link_mode').buttonset('refresh');
$Grid.jqGrid('setLabel', 'owner', '�����������');
    
}
    
    if(pd.link != link) {
        pd.link = link;
        $Grid.trigger('reloadGrid');
    }
  }



$(function() {
    
    var m = new moment(),
        start = m.format('DD-MM-YYYY');
        start += ' 00:00';

    var end   = m.format('DD-MM-YYYY');
        end   += ' 23:59';


    $('#snd').click(sendInterval);

    $('#start' ).datetimepicker({
        lang        : 'ru',
        todayButton : false,
        step        : 30,
        format      : 'd-m-Y H:i',
        formatTime  : 'H:i',
        formatDate  : 'd-m-Y',
        minTime     : '00:00',
        maxTime     : '23:59',
        value       : start,
        mask        : '39-19-3199 29:59',
        onSelectTime: function(){ $(this).hide(); },
        onShow      : function(){ $(this).trigger('changedatetime.xdsoft'); }
    });
	$('#end' ).datetimepicker({
        lang        : 'ru',
        todayButton : false,
        step        : 30,
        format      : 'd-m-Y H:i',
        formatTime  : 'H:i',
        formatDate  : 'd-m-Y',
        minTime     : '00:00',
        maxTime     : '23:59',
        value       : end,
        mask        : '39-19-3199 29:59',
        onSelectTime: function(){ $(this).hide(); },
        onShow      : function(){ $(this).trigger('changedatetime.xdsoft'); }
	});

    start += ':00';
    end   += ':00';
    
    document.title = "Hunter-V";

    $(document).mousemove(function(ev) {
        mm_event = ev;
    });

    $Grid = $("#list").jqGrid({
        url             : baseUrl + '.php',
        loadComplete    : OnGridComplete,
        datatype        : 'json',
        postData        : { i:iInit, beg:start, end:end, link:1},
        mtype           : 'POST',
        height          : screen.height > 1024 ? 450 : 350,
    colNames: ['id','� �/�', '� ����', '���� ����.','�����������', '� ����', '�������� �����', '������', '����', '�����'],
    colModel :[
      {name:'id', index:'id',search:false,sorttype:'integer',width: 30,sortable:false, align:'center', hidden:true},
      {name:'nom_pp', index:'nom_pp',width: 50, sortable:false, editable:true, align:'center' },
      {name:'nom_nakl', index:'nom_nakl',width: 80, sortable:true, editable:true, align:'center' },
      {name:'created_at', index:'created_at',width: 120, sortable:true, editable:true, align:'center',
                          formatter:'date', formatoptions: {srcformat: 'Y-m-d H:i:s', newformat: 'd.m.Y H:i'} },
      {name:'owner', index:'owner',width: 200, sortable:false, editable:true, align:'center' },
      {name:'nom_avto', index:'nom_avto',width: 80, sortable:true, editable:true, align:'center' },
      {name:'gruz', index:'gruz',width: 200, sortable:true, editable:true, align:'center' },
      {name:'brutto', index:'brutto', width: 80, sortable:false, editable:false, align:'center' },
      {name:'tara', index:'tara', width: 80, sortable:false, editable:false, align:'center' },
      {name:'netto', index:'netto',width: 80, sortable:false, editable:false, align:'center' }
    ],
        pager             : '#pager',
        rowNum            : screen.height > 1024 ? 10 : 10,
        rowList           : [10,15,30,100,500],
        sortname          : 'created_at',
        sortorder         : "desc",
        viewrecords       : true,
        caption           : '����������� ����������� Hunter-V',
        footerrow         : false,
        hidegrid          : false,
        editurl           : baseUrl + '_actions.php',
        ondblClickRow     : OnGridDblClick,
        subGrid           : true,
        subGridOptions    : {
            "plusicon"       : "ui-icon-triangle-1-e",
            "minusicon"      : "ui-icon-triangle-1-s",
            "openicon"       : "ui-icon-arrowreturn-1-e",
            "reloadOnExpand" : true,
            "selectOnExpand" : true
        },

        subGridRowExpanded : onGridExpanded
    });

    $Grid.jqGrid('navGrid','#pager', { edit:isAdmin, add:isAdmin, delfunc:deleteCard, del:isAdmin, search:false, refresh:false, pdf:true }, parEdit, parEdit)
    .navButtonAdd('#pager',{
        caption:"",
        id:'upd',
        buttonicon:"ui-icon-refresh",
        onClickButton: function() { $Grid.trigger('reloadGrid') },
        position:"first",
        title:'��������'
    });
// add custom button to export the data to excel
    $Grid.jqGrid('navButtonAdd','#pager',{
       caption:"",
       id:'id',
       buttonicon:"ui-icon-print",
       onClickButton : function () {
            $('#begin').val($('#start').val());
            $('#endend').val($('#end').val());
            $('#makePdf').submit();

       },

       title:'������� � PDF'
});

        $Grid.jqGrid('destroyGroupHeader');
	$Grid.jqGrid('setGroupHeaders', {
		useColSpanStyle: true,
		groupHeaders: [
			{startColumnName: 'brutto', numberOfColumns: 3, titleText: '����� (��)'},

		]
	});

    $('#gbox_list .ui-jqgrid-title').before('<button role="button" class="ShowHelp" style="padding-top:0;"><i class="fa fa-question-circle"> </i></button>');
    $('.ShowHelp').button().click(ShowHelp);
    $('.ShowHelp .ui-button-text').css({padding:0, 'font-size':'1.2em'});

    $Grid.jqGrid('filterToolbar',{ autoseach:true, searchOnEnter : false, stringResult: true, defaultSearch:'cn' });

$Order = $('#dlg_order').dialog({
		autoOpen    : false,
		width       : 'auto',
		height      : 'auto',
		modal       : true,
                focus       : '',
                close       : OrderCancel,
                closeOnEscape: false,
		buttons     : [
			{ text:'���������', icons:{primary: 'ui-icon-disk'}, click: OrderSave, id:'it_add'},
			{ text:'������', icons:{primary: 'ui-icon-cancel'}, click: function() { $Order.dialog('close') } }
		]
	});
        




});

 $('#dat_priem' ).datetimepicker({
        lang        : 'ru',
        todayButton : false,
        step        : 10,
        format      : 'd-m-Y H:i',
        formatTime  : 'H:i',
        formatDate  : 'd-m-Y',
        minTime     : '00:00',
        maxTime     : '23:59',
        value       : '',
        mask        : '39-19-3199 29:59',
        onShow      : dtPickShow,
        onSelectTime: function(){ $(this).hide(); }
    });

 $('#dat_otprav' ).datetimepicker({
        lang        : 'ru',
        todayButton : false,
        step        : 10,
        format      : 'd-m-Y H:i',
        formatTime  : 'H:i',
        formatDate  : 'd-m-Y',
        minTime     : '00:00',
        maxTime     : '23:59',
        value       : '',
        mask        : '39-19-3199 29:59',
        onShow      : dtPickShow,
        onSelectTime: function(){ $(this).hide(); }
	});
    
function dtPickShow(ct) {
    lastZ = parseInt($('[aria-describedby="dlg_order"]').css('z-index'));
    lastZ++;
    var zCur = $(this).css('z-index');
    if(isNaN(zCur) || zCur < lastZ) {
        $(this).css('z-index', lastZ);
    }
    $(this).trigger('changedatetime.xdsoft');
}
        
function OrderSave(id) {
	var pd = $Grid.jqGrid('getGridParam', 'postData');                
            operation = pd.link;   
	    id        = $Order.attr('oid');

    var pd = {
        id           : id,
        nom_nakl     : $('#nom_nakl').val(),
        nom_avto     : $('#nom_avto').val(),        
        otpravitel   : $('#otpravitel').val(),        
        poluchatel   : $('#poluchatel').val(),        
        plat         : $('#plat').val(),        
        perevoz      : $('#perevoz').val(),        
        gruz         : $('#gruz').val(),        
        brutto       : $('#brutto').val(),        
        tara         : $('#tara').val(),        
        netto        : $('#netto').val(),        
        dat_priem    : $('#dat_priem').val(),        
        priemshik    : $('#priemshik').val(),        
        dat_otprav   : $('#dat_otprav').val(),        
        otpravshik   : $('#otpravshik').val(),        
        nom_pricep   : $('#nom_pricep').val(),        
        brutto_pricep: $('#brutto_pricep').val(),        
        tara_pricep  : $('#tara_pricep').val(),        
        netto_pricep : $('#netto_pricep').val(),        
        oper         : 'link', 
        operation    : operation
   

    };

   	$.post(
		baseUrl + '_action.php',
		pd,
		function(answ) {
  
			if (answ.warning) {
                 	    jAlert(answ.warning,'��������������!');
			}
			if (answ.status != 'ok'){
			    jAlert(answ.status);
                            return;
			}
            $Order.dialog('close');
            $Grid.trigger('reloadGrid');
		},
        'json'
	);
}

    // �������� ������� ��� ������� �� +
    $('#add_prihod').button().click(function() {$Order.dialog( "option", "title", "������ ������" ); $Order.dialog('open'); });
    $('#add_rashod').button().click(function() {$Order.dialog( "option", "title", "������ ������" ); $Order.dialog('open'); });


function OrderCancel() {

        $('#firm_id option:eq(0)').prop('selected', true);
	$('#firm_id ').prop('disabled', false);
	$('#car_id')
		.val($('#car_id').attr('b'))
		.attr('cid', 0)
		.prop('disabled', false);
	$('#car_num').val('').attr('bt', '');

	$('#dlg_order select').val(0);

}



function sendInterval() {
    var pd = $Grid.jqGrid('getGridParam', 'postData'),
        beg = regDt.exec($('#start').val()),
        end = regDt.exec($('#end').val());
    if(beg && end) {
        pd.beg = beg[3] + '-' + beg[2] + '-' + beg[1] + ' ' + beg[4] + ':00';
        pd.end = end[3] + '-' + end[2] + '-' + end[1] + ' ' + end[4] + ':00';
        $Grid.trigger('reloadGrid');
    }
}

function fmtHex(cv) {
    return parseInt(cv).toString(16).toUpperCase();
}

function OnGridComplete(aDat) {
    $Grid.jqGrid('getGridParam', 'postData').i = 0;
}

function OnGridDblClick(rowid, iR, iC, ev) {
    var $tbl = $(ev.target).closest('table');
    if(!canEdit) return;
    if($tbl.attr('id') == 'list') {
        if(iC == 0) return;
        $Grid.jqGrid('editGridRow', rowid, parEdit );
    } else {
        $tbl.jqGrid('editGridRow', rowid, parEditHist );
    }
}

function AttrId() {    return ' class="ui-state-default"'; }

function FmtUnit(cv) {
    var x = cv.split('|');
    return '<span uid="' + x[1] + '">' + x[0] + '</span>';
}

function FmtParam(cv) {
    var t = [];
    $.each(aFlags, function(k,v){
        if(cv & v.f) {
            var c = '';
            switch(v.s) {
                case 1: c = 'ui-state-highlight'; break;
                case 2: c = 'ui-state-error'; break;
            }
            t.push('<li class="' + c + '" title="' + v.t + '"><i class="fa fa-' + v.i + '"> </i></li>');
        }
    });
    return '<ul class="ul_param" flg="' + cv + '">' + t.join('') + '</ul>';
}

function fmtOwn(cv, opt, row) {
    var a   = row[5].split('|'),
        ico = ['question','car','user'][parseInt(a[0])];
    return '<i class="fa fa-fw fa-' + ico + '"> </i>&nbsp;<span>' + cv + '</span>&nbsp;' +
            '<span class="sub">' + a[1] + '</span>'
}

function SelectUnit(ev, ui) {
    $('#unit').val(ui.item.value).attr('uid', ui.item.id).removeClass('tbl_bad');
}
function SearchUnit(req, rsp)  { $('#unit').attr('uid', 0); SearchItem('unit',  req, rsp); }
function SearchItem(what, req, rsp) {
    $DlgLdr.show();
    $.post(dir + '/search.php', {a:what, s:req.term, nd:Date.now()}, rsp, 'json').always(function(){$DlgLdr.hide();})
}

function FlagEditorCreate (value, opt) {
    var lst = [],
        val = $(value).attr('flg');
    $.each(aFlags, function(k,v){
        lst.push('<input type="checkbox" class="tbl_ok" id="flgChk_' + v.f + '"' +
                    (val & v.f ? ' checked' : '') + '/><label for="flgChk_' +
                    v.f + '">&nbsp;&nbsp;' + v.t + '</label>');
    });
    var el = $('<div>' + lst.join('<br>') + '</div>');
    return el[0];
}

function FlagEditorValue(elem, oper, value) {
    if(oper === 'get') {
        var f = 0;
        $.each(aFlags, function(k,v){
            if($('#flgChk_' + v.f).prop('checked')) f += v.f;
        });
        return f;
    } else if(oper === 'set') {
        var val = $(value).attr('flg');
        $.each(aFlags, function(k,v){
            $('#flgChk_' + v.f).prop('checked', val & v.f);
        });
    }
}

function PriceGetArray(v) {
    var all = [],
        tmp = v.split(';');

    $.each(tmp, function(k,v){
        var prc = v.split(':');
        all[ parseInt(prc[0]) ] = parseFloat(prc[1]);
    });
    return all;
}

function PriceEditorCreate (value, opt) {
    var lst = [],
        all = PriceGetArray(value);
    $.each(aFrmGrp, function(k,v){
        var vv = all[v.i] ? all[v.i] : 0;
        lst.push('<tr><td>' + v.n + '</td><td><input size="8" type="text" class="tbl_ok" id="prc_' + v.i + '" value = "' + vv + '"/></td></tr>');
    });
    var el = $('<table>' + lst.join('') + '</table>');
    return el[0];
}

function PriceEditorValue(elem, oper, value) {
    if(oper === 'get') {
        var f = [];
        $.each(aFrmGrp, function(k,v){
            var t = $('#prc_' + v.i).val(),
                a = regPrice.exec(t),
                p = '0.00';
            if(a) {
                p = a[1] + '.' + (a[3] ? a[3] : '00');
            }
            f.push(v.i + ':' + p);
        });
        return f.join(';');
    } else if(oper === 'set') {
        var all = PriceGetArray(value);
        $.each(aFrmGrp, function(k,v){
            var vv = all[v.i] ? all[v.i].toFixed(2) : '0.00';
            $('#prc_' + v.i).val(vv);
        });
    }
}

function initCardForm($form) {
    frm = $form;
    $form.children().addClass('tbl_frm');
    $('.navButton', frm).html('<div id="dlg_loader" style="float:left;margin-top:8px;"><img src="./images/loading.gif"></div>');
    $DlgLdr = $('#dlg_loader').hide();

    $('#number').keyup(KeyUpText).addClass('tbl_ok');
    $('#article').keyup(KeyUpText).addClass('tbl_ok');
    $('#firm_id').addClass('tbl_ok');

}

function initHistoryForm($form) {
    var frm = $form,
        add = $form.closest('[id^="editmodt_"]').attr('id');
    console.log(mm_event);
    $form.children().addClass('tbl_frm');
    $('.navButton', frm).html('<div id="dlg_loader" style="float:left;margin-top:8px;"><img src="./images/loading.gif"></div>');
    $DlgLdr = $('#dlg_loader').hide();

    $('#start').datetimepicker({
        lang        : 'ru',
        todayButton : false,
        step        : 30,
        format      : 'd.m.Y H:i',
        formatTime  : 'H:i',
        formatDate  : 'd.m.Y',
        mask        : '39.19.3199 29:59',
        onSelectTime: function(){ $(this).hide(); },
        onShow      : function(){ $(this).trigger('changedatetime.xdsoft'); }
    }).addClass('tbl_ok');
    $('#end').datetimepicker({
        lang        : 'ru',
        todayButton : false,
        step        : 30,
        minDate     : '01.01.2016',
        format      : 'd.m.Y H:i',
        formatTime  : 'H:i',
        formatDate  : 'd.m.Y',
        mask        : '39.19.3199 29:59',
        onSelectTime: function(){ $(this).hide(); },
        onShow      : function(){ $(this).trigger('changedatetime.xdsoft'); }

    }).addClass('tbl_ok');

}

function checkCard(pd) {
    var aBad = [];
    $('.tbl_bad').removeClass('tbl_bad');
    if(!regHex.exec(pd.number)) { aBad.push({i:'name', m:'������� 16-���� ����� ����� (1-10 ��������)'}); }
    if(pd.article.length < 3) { aBad.push({i:'text', m:'������� ������������ ����� (�� ����� 3����.)'}); }

    console.log(pd);

    if(aBad.length > 0) {
        var aMsg = [];
        $.each(aBad, function(k,v){
            aMsg.push(v.m);
            $('#' + v.i).addClass('tbl_bad');
        });
        jError(aMsg.join('<br>'))
        return [false, '��������� ������'];
    }

    pd.number = parseInt(pd.number, 16);

    return [true, ''];
}

function afterSubmit(rsp, pd) {
    if(rsp.status != 200) {
        return [false, '������ ���������� : ' + rsp.status + ' (' + rsp.statusText + ')', 0];
    }
    var ans = $.parseJSON(rsp.responseText);
    if(ans.status != 'ok') {
        jError(ans.status);
        if(pd.oper && pd.oper == 'add') {
            return [false, ans.status, 0];
        }
    }
    var id = ans.id ? ans.id : 0;
    return [true, '', id];
}

function deleteCard(id) {
    var rd = $Grid.jqGrid('getRowData', id);
    jConfirm('������� ��������� <b>' + ' �'+rd.nom_nakl + '</b> ?', '��������!', function(a){
        if(!a) return;
        $.post(
            baseUrl + '_action.php',
            { id:id, oper:'del' },
            function(rsp) {
                if(rsp && rsp.status != 'ok') {
                    jAlert(rsp.status);
                    return;
                }
                $Grid.trigger('reloadGrid');
            },
            'json'
        );
    });
}

function ShowHelp() {
    if($Help == null) {
        $Help = $('#dv_help').dialog({
            title: '�������',
            width: 900,
            buttons: [
                {text:'�������', icons:{primary:'ui-icon-close'}, click: function(){ $Help.dialog('close'); }}
            ]
        });
    }
    $Help.dialog('open');
}

function KeyUpRegEx(o, r) {
    o.removeClass('tbl_bad');
    if(!r.test(o.val())) { o.addClass('tbl_bad'); return false; }
    return true;
}
function KeyUpText(ev) { KeyUpRegEx($(this), /^.{10,}$/); }
function KeyUpUnit(ev) { if(!KeyUpRegEx($(this), /^.{1,}$/)) { $('#unit').attr('uid', 0); } }
function KeyUpPrice(ev) { KeyUpRegEx($(this), regPrice); }
function KeyUpIntVal(o, iMin) {
    o.removeClass('tbl_bad');
    var v = o.val();
    if(isNaN(v) || v < iMin) o.addClass('tbl_bad');
}
function KeyUpStep(ev) { KeyUpIntVal($(this), 2); }
function KeyUpInt(ev) { KeyUpIntVal($(this), 0); }

function onGridExpanded(sub_id, rid) {
    var tblId    = 't_' + sub_id,
        pgrId    = 'p_' + sub_id;

    $("#" + sub_id).html("<table id='" + tblId + "' class='scroll'></table><div id='" + pgrId + "' class='scroll'></div>");

    $GridSub = $("#" + tblId).jqGrid({

    url       : baseUrl + "_sub.php",
    postData  : { sid: rid },
    datatype  : "json",
    mtype     : "POST",
    colNames: ['������','�������','�����','�����','Owner_id'],
    colModel: [
      {name:"start",index:"start",width:100, editable:true, align:"center"},
      {name:"name",index:"name",width:250, align:"left"},
      {name:"sub",index:"sub",width:150, align:"center"},
      {name:"end",index:"end",width:100, editable:true, align:"center"},
      {name:"card_id",index:"card_id", editable:true, hidden:true}
    ],
        pager             : pgrId,
        height            : '100%',
        altRows           : true,
        footerrow         : true,
        viewrecords       : true,
        caption           : 'I����i� ���� �����',
        editurl           : baseUrl + '_actions.php'

    });
    $("#"+tblId).jqGrid(
        'navGrid',
        '#'+pgrId,
        {
            edit    : canEdit,
            add     : false,
            del     : canEdit,
            delfunc : deleteHistory,
            search  : false,
            refresh : false
        }
    )
    .navButtonAdd('#'+pgrId, {
        caption:"",
        id:'upd_' + sub_id,
        buttonicon:"ui-icon-refresh",
        onClickButton: function() { $GridSub.trigger('reloadGrid') },
        position:"first",
        title:'��������'
    });

}

function FmtGrp(cv) {
    var x = cv.split('|');
    return '<span gid="' + x[0] + '">' + x[1] + '</span>';
}

function deleteHistory(id) {
    var $GridSub = $(this),
        card = $GridSub.jqGrid('getGridParam', 'postData').sid,
        rd   = $GridSub.jqGrid('getRowData', id);

    jConfirm('������� ������ ����� �� <b>' + rd.name + '</b>' +
             '<span class="licplate">' + rd.sub + '</span>\n' +
             '� <b>' + rd.start + '</b>?', '��������!', function(a){
        if(!a) return;
        $.post(
            baseUrl + '_actions.php',
            { id:id, oper:'del_hist' },
            function(rsp) {
                if(rsp && rsp.status != 'ok') {
                    jAlert(rsp.status);
                    return;
                }
                $GridSub.trigger('reloadGrid');
            },
            'json'
        );
    });
}