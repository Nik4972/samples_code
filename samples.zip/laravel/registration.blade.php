@extends('base/page')

@section('title')
	<title>Регистрация на портале Websmart.center</title>
@overwrite

@section('meta')
	<meta name="description" content="Регистрация на Websmart.center. Станьте участником первого портала ПРОФЕССИОНАЛОВ по развитию личности!" />
	<meta name="keywords" content="Websmart center, вебсмарт центр, регистрация" />
@overwrite

@section('breadcrumb')
<div class="breadcrumb-block uk-margin-top-remove breadcrumbs-for-registration">
	<div class="uk-container uk-container-center">
		<ul class="uk-breadcrumb">
			<li><a href="/">Главная</a></li>
			<li class="uk-active"><span>Регистрация</span></li>
		</ul>
	</div>
</div>
@stop

@section('content')
	<div class="main">
        <div class="registration-cont">
            <div class="registration-cont-substrate">
                <h1 class="registration-cont-head">Я хочу зарегистрироваться</h1>

                <div id="form-wrapper" class="registration-cont-content">
                    <form id="registrationForm">
                        <input type="hidden" name="_token" value="{!! csrf_token() !!}" />
                        <div id="errors"></div>

                        <div class="row">
                            <div class="col-sm-6">
                                <input
                                       id="role1"
                                       type="radio"
                                       name="role"
                                       value="company"
                                       style="display:none;"
                                       class="registration-cont-radio"/>
                                <label class="main-button registration-cont-btn" for="role1">
                                    <span>Как профессионал</span>
                                    <span class="registration-cont-btn-hint">Вы сможете размещать информацию о себе и/или о компании, свои статьи, тренинги, услуги, получать заявки на ваши мероприятия участвовать в реферальной программе и многое другое</span>
                                </label>
                            </div>
                            <div class="col-sm-6">
                                <input
                                       id="role2"
                                       type="radio"
                                       name="role"
                                       value="user"
                                       style="display:none;"
                                       class="registration-cont-radio"/>
                                <label class="main-button registration-cont-btn" for="role2">
                                    <span>Как пользователь</span>
                                    <span class="registration-cont-btn-hint">Вы сможете получить наиболее свежую информацию о планируемых событиях,размещать тендеры для обучения своих сотрудников, участвовать в реферальной программе.</span>
                                </label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <label class="registration-cont-content-label" for="name">Ваше имя</label>
                                <input class="registration-cont-content-input"
                                       type="text"
                                       id="name"
                                       placeholder="Ваше имя"
                                       name="name">
                            </div>
                            <div class="col-sm-6">
                                <label class="registration-cont-content-label" for="surname">Ваша фамилия</label>
                                <input class="registration-cont-content-input"
                                       type="text"
                                       id="surname"
                                       placeholder="Ваша фамилия"
                                       name="surname">
                            </div>
                            <div class="col-sm-12">
                                <div class="registration-cont-content-bottom">Ваше имя и фамилия может быть доступно другим участникам</div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <label class="registration-cont-content-label" for="email">Электронная почта</label>
                                <input class="registration-cont-content-input"
                                       type="text"
                                       id="email"
                                       placeholder="Электронная почта"
                                       name="email">
                                <div class="registration-cont-content-bottom">Введите вашу электронную почту правильно, т.к. на нее будет выслано подтверждающее письмо</div>
                            </div>
                            <div class="col-sm-6">
                                <label class="registration-cont-content-label" for="phone">Телефон</label>
                                <input class="registration-cont-content-input"
                                       type="text"
                                       id="phone"
                                       placeholder="+380*********"
                                       name="phone">
                                <div class="registration-cont-content-bottom">Введите номер телефона в формате +380********* без пробелов и других символов</div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <label class="registration-cont-content-label" for="password">Придумайте пароль</label>
                                <input class="registration-cont-content-input"
                                       type="password"
                                       id="password"
                                       name="password">
                            </div>
                            <div class="col-sm-6">
                                <label class="registration-cont-content-label" for="password_confirmation">Повторите пароль</label>
                                <input class="registration-cont-content-input"
                                       type="password"
                                       id="password_confirmation"
                                       name="password_confirmation">
                            </div>
                            <div class="col-sm-12">
                                <div class="registration-cont-content-bottom">Пароль должен иметь цифры и буквы латинского алфавита, минимум 6 символов, максимум 64 символа</div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <label class="registration-cont-content-label" for="company">Если вы представляете компанию, введите ее название</label>
                                <input class="registration-cont-content-input"
                                       type="text"
                                       id="company"
                                       placeholder="Компания"
                                       name="company">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <label class="registration-cont-content-label" for="code">Реферальный код</label>
                            </div>

                            <div class="col-sm-6">
                                <input class="registration-cont-content-input"
                                       type="text"
                                       id="code"
                                       name="code"
                                       value="{{ $code }}">
                            </div>
                            <div class="col-sm-6">
                                <a href="{!! action('PublicController@getReferralCode') !!}" class="uk-button uk-button-small mod">Как получить реферальный код ?</a>
                            </div>

                            <div class="col-sm-12">
                                <div class="registration-cont-content-bottom">Используя реферальный код своего коллеги вы получаете пожизненную скидку в 10% на все пакеты сайта.</div>
                            </div>
                        </div>

                        <div class="registration-cont-bottom">
                            <div class="registration-cont-bottom-text">
                                <span>Регистрируясь, вы соглашаетесь с</span>
                                <a href="{!! action('PublicController@getRules') !!}"
                                   target="_blank">пользовательским соглашением</a>
                            </div>
                            <div class="registration-cont-bottom-btn">
                                <input id="submitRegistration" class="main-button" type="submit" value="Зарегистрироваться">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
	</div>
@stop

@section('scripts')w
<script type="text/javascript">

	$("#phone").blur(function(){
		$(this).val(jQuery.trim($(this).val()))
	});

	@parent
	@include('scripts.ajaxForm',[
	'submitBtn' => '#submitRegistration',
	'url'       => 'AuthController@postRegistration',
	'form'      => '#registrationForm'
	])
</script>
@stop
