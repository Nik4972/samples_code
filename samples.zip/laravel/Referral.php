<?php

namespace App\Http\Requests;

class Referral extends Request {

	public function all()
	{
		$input = parent::all();

		$summa = str_replace(" ", "", $input['summa']);
		$summa = str_replace(",", ".", $summa);
		$summa = str_replace("-", "", $summa);

		$input['summa'] = number_format($summa, 2, '.', '');

		$this->replace($input);

		return $input;
	}

	public function rules()
	{
		return [
			'email' => 'required|email|max:64',
			'name' => 'required|max:128',
			'phone' => 'required|regex:/^[+0-9]+$/',
			'company' => 'max:32',
			'summa' => 'required|between:300,'.\Auth::user()->current_summa.'|numeric',
			'info' => 'max:1024',
		];
	}


	public function authorize()
	{
		return true;
	}


	public function messages()
	{
		if (\Auth::user()->current_summa < 300)
		{
			return [
				'name.required' => 'Введите имя',
				'name.max' => 'Имя не более :max символов',
				'company.max' => 'Компания не более :max символов',
				'info.max' => 'Информация не более :max символов',
				'phone.required' => 'Введите контактный телефон',
				'phone.regex' => 'Номер телефона должен содержать только цифры и начинаться со знака +',
				'phone.max' => 'Номер телефона должен состоять из цифр и знака + перед ними',
				'phone.min' => 'Номер телефона должен состоять из цифр и знака + перед ними',
				'email.required' => 'Введите контактный email',
				'email.max' => 'Контактный email не более :max символов',
				'email.email' => 'Введите корректный контактный email',
				'summa.required' => 'Введите сумму для вывода средств',
				'summa.numeric' => 'Сумма должна быть числом',
				'summa.between' => 'Недостаточно средств для вывода',
			];
		}
		else
		{
			return [
				'name.required' => 'Введите имя',
				'name.max' => 'Имя не более :max символов',
				'company.max' => 'Компания не более :max символов',
				'info.max' => 'Информация не более :max символов',
				'phone.required' => 'Введите контактный телефон',
				'phone.regex' => 'Номер телефона должен содержать только цифры и начинаться со знака +',
				'phone.max' => 'Номер телефона должен состоять из цифр и знака + перед ними',
				'phone.min' => 'Номер телефона должен состоять из цифр и знака + перед ними',
				'email.required' => 'Введите контактный email',
				'email.max' => 'Контактный email не более :max символов',
				'email.email' => 'Введите корректный контактный email',
				'summa.required' => 'Введите сумму для вывода средств',
				'summa.numeric' => 'Сумма должна быть числом',
				'summa.between' => 'Вы можете вывести от 300 до '.number_format(\Auth::user()->current_summa, 2, '.', '').' грн',
			];
		}
	}
}
