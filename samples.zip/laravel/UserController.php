<?php

namespace App\Http\Controllers;

use App\Http\Requests\Buy;
use App\Http\Requests\Referral;
use App\Http\Requests\Tender\Create as CreateTender;
use App\Http\Requests\Tender\Delete as DeleteTender;
use App\Http\Requests\User\CommentRaiting;
use App\Http\Requests\User\CreateComment;
use App\Http\Requests\User\DeleteInvoice;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class UserController extends Controller {

	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('protectionCode', [
			'only' => [
				'getDeleteTender',
				'getDeleteInvoice',
			],
		]);
	}


	public function getOutgoingTenders($currentPage = null)
	{
		$user = \Auth::user();

		if ($user->role == 'company')
		{
			$view = view('company/tenders/outgoing');
		}
		else
		{
			$view = view('user/tenders/outgoing');
		}

		$date = \Carbon\Carbon::now()
		                      ->format('Y-m-d');

		$total = \App\Models\Tender::where('user_id', $user->id)
		                           ->count();

		$sql = \App\Models\Tender::where('user_id', $user->id)
		                         ->orderBy('id', 'desc');

		$view->tenders = FSPagination($sql, $total, $currentPage, 10);
		$view->date = $date;

		return $view;
	}


	public function getShowTender($id)
	{
		$user = \Auth::user();

		$tender = \App\Models\Tender::where('user_id', $user->id)
		                            ->where('id', $id)
		                            ->first();

		if ($user->role == 'company')
		{
			$view = view('company/tenders/index');
		}
		else
		{
			$view = view('user/tenders/index');
		}

		$view->tender = $tender;

		return $view;
	}


	public function getViewTender($id)
	{
		$user = \Auth::user();

		$tender = \App\Models\Tender::find($id);

		if ($user->role == 'company')
		{
			$currentPayment = \App\Models\Payment::find($user->payment_id);

			$package = $currentPayment->package;

			if ($package->tenders)
			{
				$view = view('company/tenders/show');
			}
			else
			{
				flash('Настройки текущего тарифного пакета не позволяют выполнить это действие', 'primary');

				return back();
			}
		}
		else
		{
			$view = view('user/tenders/show');
		}

		$view->tender = $tender;

		return $view;
	}


	public function postCreateTender(CreateTender $request)
	{
		$user = \Auth::user();

		$tender = new \App\Models\Tender();

		$tender->user_id = $user->id;
		$tender->name = e($request->name);
		$tender->target = e($request->target);
		$tender->auditory = e($request->auditory);
		$tender->listeners = e($request->listeners);
		$tender->address = e($request->address);
		$tender->date = e($request->date);
		$tender->price = e($request->price);
		$tender->info = e($request->info);
		$tender->contact_name = e($request->contact_name);
		$tender->contact_company = e($request->contact_company);
		$tender->contact_phone = e($request->contact_phone);
		$tender->contact_email = e($request->contact_email);
		$tender->end_date = e($request->end_date);
		$tender->moderated = true;

		$tender->save();

		flash('Тендер создан, после модерации мы разошлем его всем компаниям', 'success');
	}


	public function postEditTender(CreateTender $request)
	{
		$user = \Auth::user();

		$tender = \App\Models\Tender::where('user_id', $user->id)
		                            ->where('id', $request->id)
		                            ->first();

		$tender->name = e($request->name);
		$tender->target = e($request->target);
		$tender->auditory = e($request->auditory);
		$tender->listeners = e($request->listeners);
		$tender->address = e($request->address);
		$tender->date = e($request->date);
		$tender->price = e($request->price);
		$tender->info = e($request->info);
		$tender->contact_name = e($request->contact_name);
		$tender->contact_company = e($request->contact_company);
		$tender->contact_phone = e($request->contact_phone);
		$tender->contact_email = e($request->contact_email);
		$tender->end_date = e($request->end_date);
		$tender->active = false;
		$tender->moderated = true;

		$tender->save();

		flash('Изменения сохранены, после модерации мы разошлем его всем компаниям', 'success');
	}


	public function getEditTender($id)
	{
		$user = \Auth::user();

		$tender = \App\Models\Tender::where('user_id', $user->id)
		                            ->where('id', $id)
		                            ->first();

		if ($user->role == 'company')
		{
			$view = view('company/tenders/edit');
		}
		else
		{
			$view = view('user/tenders/edit');
		}

		$view->tender = $tender;

		return $view;
	}


	public function getDeleteTender($id)
	{
		$user = \Auth::user();

		$tender = \App\Models\Tender::where('user_id', $user->id)
		                            ->where('id', $id)
		                            ->first();

		$view = view('user/tenders/delete');

		$view->tender = $tender;

		return $view;
	}


	public function postDeleteTender(DeleteTender $request)
	{
		$user = \Auth::user();

		$tender = \App\Models\Tender::where('user_id', $user->id)
		                            ->where('id', $request->id)
		                            ->first();

		$tender->delete();

		return response()->json([
			'message' => 'Тендер удален',
			'type' => 'success',
			'refresh' => true,
		]);
	}


	public function getBids($currentPage = null)
	{
		$user = \Auth::user();

		$view = view('user/bids');

		$total = \App\Models\Bid::where('user_id', $user->id)
		                        ->where('deleted_user_id', '<>', $user->id)
		                        ->count();

		$sql = \App\Models\Bid::where('user_id', $user->id)
		                      ->where('deleted_user_id', '<>', $user->id)
		                      ->with('service')
		                      ->with('service.trainers')
		                      ->orderBy('id', 'desc');

		$view->bids = FSPagination($sql, $total, $currentPage, 10);

		return $view;
	}


	public function getBid($id)
	{
		$user = \Auth::user();

		$view = view('user/bid');

		$view->bid = \App\Models\Bid::where('user_id', $user->id)
		                            ->where('id', $id)
		                            ->first();

		return $view;
	}


	public function postDeleteBid(Request $request)
	{
		$user = \Auth::user();

		$bid = \App\Models\Bid::where('user_id', $user->id)
		                      ->where('id', $request->id)
		                      ->first();

		if ($bid->deleted_user_id != 0)
		{
			$bid->delete();
		}
		else
		{
			$bid->deleted_user_id = $user->id;

			$bid->save();
		}

		$view = response()->json([
			'message' => 'Заявка удалена',
			'type' => 'success',
		]);

		return $view;
	}


	public function getMyCode()
	{
		$view = view('user/code');

		return $view;
	}


	public function getMyPromotions()
	{
		$view = view('user/promotions');

		return $view;
	}


	public function getMyReferrals($currentPage = null)
	{
		$view = view('user/referrals');

		$user = \Auth::user();

		$total = \App\Models\User::where('referral_first_level', $user->code)
		                         ->orWhere('referral_second_level', $user->code)
		                         ->count();

		$sql = \App\Models\User::where('referral_first_level', $user->code)
		                       ->orWhere('referral_second_level', $user->code)
		                       ->orderBy('id', 'desc');

		$view->referrals = FSPagination($sql, $total, $currentPage, 20);

		return $view;
	}


	public function getMyReferralsPayment($currentPage = null)
	{
		$view = view('user/referralsPayment');

		$user = \Auth::user();

		$total = \App\Models\ReferralPayment::where('referral_id', $user->id)
		                                    ->count();

		$sql = \App\Models\ReferralPayment::where('referral_id', $user->id)
		                                  ->with('user')
		                                  ->orderBy('id', 'desc');

		$view->referrals = FSPagination($sql, $total, $currentPage, 20);
		$view->summa = number_format($user->current_summa, 2, '.', '');

		return $view;
	}


	public function getGiveMyReferralMoney()
	{
		$view = view('giveMyReferralMoney');

		return $view;
	}


	public function postGiveMyReferralMoney(Referral $request)
	{
		$user = \Auth::user();

		$referralRequest = new \App\Models\ReferralRequest();

		$referralRequest->user_id = $user->id;
		$referralRequest->name = e($request->name);
		$referralRequest->email = e($request->email);
		$referralRequest->phone = e($request->phone);
		$referralRequest->company = e($request->company);
		$referralRequest->info = e($request->info);
		$referralRequest->summa = number_format($request->summa, 2, '.', '');

		$referralRequest->save();

		$payment = new \App\Models\ReferralPayment();

		$payment->user_id = $user->id;
		$payment->referral_id = $user->id;
		$payment->price = '-'.number_format($request->summa, 2, '.', '');

		$payment->save();

		$user->current_summa = number_format($user->current_summa - $request->summa, 2, '.', '');

		$user->save();

		return response()->json([
			'message' => 'Запрос на вывод средств отправлен',
			'type' => 'success',
		  'refresh' => true
		]);
	}


	public function postCreateComment(CreateComment $request)
	{
		$comment = new \App\Models\Comment();

		$comment->commented_id = $request->commented_id;
		$comment->commented_type = $request->commented_type;
		$name = \Auth::user()->fullname;

		if (\Auth::user()->role == 'company')
		{
			$company_name = \Auth::user()->company;
			$name = $name.', '.$company_name;

			if (\Auth::user()->type == 'multiple')
			{
				$name = \App\Models\Trainer::find(e($request->name))->fullname.', '.$company_name;
			}
		}

		$comment->name = $name;
		$comment->user_id = \Auth::user()->id;

		if ($request->has('comment_id'))
		{
			$comment->comment_id = $request->comment_id;
		}
		else
		{
			$comment->comment_id = null;
		}

		$comment->status = false;

		$comment->content = typography(e($request->text_content));

		$comment->save();

		return response()->json([
			'message' => 'Комментарий будет опубликован на сайте после модерации администратором',
			'type' => 'success',
		]);
	}


	public function postReitedComment(CommentRaiting $request)
	{
		$user = \Auth::user()->id;
		$comments_rating = \App\Models\CommentsRaiting::where('user_id', $user)
		                                              ->where('comment_id', intval($request->id))
		                                              ->count();

		if (!$comments_rating)
		{
			$comment = \App\Models\Comment::find(intval($request->id));

			if (intval($request->type))
			{
				$comment->rating_plus += 1;
			}
			else
			{
				$comment->rating_minus += 1;
			}

			$comment->save();

			\App\Models\CommentsRaiting::create([
				'user_id'    => $user,
				'comment_id' => intval($request->id),
			]);

			return response()->json([
				'message' => 'Ваш голос учтен',
				'type' => 'success',
			]);
		}
		else
		{
			return response()->json([
				'message' => 'Вы уже голосовали за этот комментарий',
				'type' => 'danger',
			]);
		}
	}


	public function getBuyPackage($id, $duration = 'one')
	{
		$view = view('buyPackage');

		$package = \App\Models\Package::find($id);
		$user = \Auth::user();

		if ($duration == 'six')
		{
			$price = $package->price_six_months;
			$month = 6;
		}
		elseif ($duration == 'three')
		{
			$price = $package->price_three_months;
			$month = 3;
		}
		else
		{
			$price = $package->price_one_months;
			$month = 1;
		}

		if (!is_null($user->referral_first_level))
		{
			$price = sale($price, 10);
		}

		$view->package = $package;
		$view->price = $price;
		$view->month = $month;
		$view->duration = $duration;

		return $view;
	}


	public function postBuyPackage(Buy $request)
	{
		$invoice = new \App\Models\Payment();

		$package = \App\Models\Package::find($request->id);
		$user = \Auth::user();

		if ($request->duration == 'six')
		{
			$price = $package->price_six_months;
			$month = 6;
		}
		elseif ($request->duration == 'three')
		{
			$price = $package->price_three_months;
			$month = 3;
		}
		else
		{
			$price = $package->price_one_months;
			$month = 1;
		}

		if (!is_null($user->referral_first_level))
		{
			$price = sale($price, 10);
		}

		$invoice->user_id = $user->id;
		$invoice->package_id = $package->id;
		$invoice->price = $price;
		$invoice->duration = $month;
		$invoice->expired = \Carbon\Carbon::now()
		                                  ->addMonths($month);

		$invoice->save();

		$invoice->sign = sign($invoice->id, $price, $invoice->description);

		$invoice->save();

		return response()->json([
			'message' => 'Cчет сформирован',
			'type' => 'success',
			'redirect' => true,
			'location' => action('CompanyController@getInvoices'),
		]);
	}


	public function getDeleteInvoice($id)
	{
		$view = view('invoice/delete');

		$view->invoice = \App\Models\Payment::where('user_id', \Auth::user()->id)
		                                    ->where('id', $id)
		                                    ->first();

		return $view;
	}


	public function postDeleteInvoice(DeleteInvoice $request)
	{
		$invoice = \App\Models\Payment::where('user_id', \Auth::user()->id)
		                              ->where('id', $request->id)
		                              ->first();

		if ($invoice->paid)
		{
			$invoice->delete();
		}
		else
		{
			$invoice->archive = true;
			$invoice->save();
		}

		return response()->json([
			'message' => 'Cчет удален',
			'type' => 'success',
			'refresh' => true,
		]);
	}


	public function postPaymentSuccess(Request $request)
	{
		$invoice = \App\Models\Payment::where('user_id', \Auth::user()->id)
		                              ->where('id', $request->ik_pm_no)
		                              ->first();

		if ($request->ik_inv_st == 'success')
		{
			$invoice->paid = true;
			$invoice->expired = \Carbon\Carbon::now()
			                                  ->addMonths($invoice->duration);

			$invoice->save();
		}

		if (!is_null($invoice->price))
		{
			$user = \App\Models\User::find($invoice->user_id);

			if (!is_null($user->referral_first_level))
			{
				$referral_first_level = \App\Models\User::where('code', $user->referral_first_level)
				                                        ->first();

				if ($referral_first_level)
				{
					\DB::table('referrals_payment')
					  ->insert([
						  'user_id' => $invoice->user_id,
						  'referral_id' => $referral_first_level->id,
						  'price' => number_format($invoice->price * 0.09, 2, '.', ''),
						  'created_at' => \Carbon\Carbon::now(),
						  'updated_at' => \Carbon\Carbon::now(),
					  ]);

					$referral_first_level->total_summa = number_format($referral_first_level->total_summa + $invoice->price * 0.09, 2, '.', '');
					$referral_first_level->current_summa = number_format($referral_first_level->current_summa + $invoice->price * 0.09, 2, '.', '');

					$referral_first_level->save();
				}
			}

			if (!is_null($user->referral_second_level))
			{
				$referral_second_level = \App\Models\User::where('code', $user->referral_second_level)
				                                         ->first();

				if ($referral_second_level)
				{
					\DB::table('referrals_payment')
					  ->insert([
						  'user_id' => $invoice->user_id,
						  'referral_id' => $referral_second_level->id,
						  'price' => number_format($invoice->price * 0.03, 2, '.', ''),
						  'created_at' => \Carbon\Carbon::now(),
						  'updated_at' => \Carbon\Carbon::now(),
					  ]);

					$referral_second_level->total_summa = number_format($referral_second_level->total_summa + $invoice->price * 0.03, 2, '.', '');
					$referral_second_level->current_summa = number_format($referral_second_level->current_summa + $invoice->price * 0.03, 2, '.', '');

					$referral_second_level->save();
				}
			}
		}

		return redirect()->action('CompanyController@getInvoices');
	}


	public function postPaymentFail()
	{
		flash('Платеж не принят платежной системой :(', 'danger');

		return redirect()->action('CompanyController@getInvoices');
	}
}
