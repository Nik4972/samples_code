<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Service extends Model {

	protected $dates = [
		'start_date',
		'end_date',
		'sidebar_date',
	];

	protected $appends = [
		'sidebar_date',
	];

	protected $dateFormat = 'Y-m-d';


	public function company()
	{
		return $this->belongsTo('App\Models\Company', 'company_id', 'company_id');
	}


	public function user()
	{
		return $this->belongsTo('App\Models\User', 'company_id', 'id');
	}


	public function places()
	{
		return $this->hasMany('App\Models\ServicePlace');
	}


	public function trainers()
	{
		return $this->belongsToMany('App\Models\Trainer', 'service_trainer');
	}


	public function specializations()
	{
		return $this->belongsToMany('App\Models\Specialization', 'service_specialization');
	}


	public function getStartDateAttribute($value)
	{
		if (!is_null($value))
		{
			return \Carbon\Carbon::parse($value)
			                     ->format('d.m.y');
		}
	}


	public function getEndDateAttribute($value)
	{
		if (!is_null($value))
		{
			return \Carbon\Carbon::parse($value)
			                     ->format('d.m.y');
		}
	}


public function getSidebarDateAttribute()
	{
		setlocale(LC_ALL, 'ru_RU.utf8');

		if (!is_null($this->start_date))
		{
			$pre_month = \Carbon\Carbon::parse($this->start_date)
			                     ->formatLocalized('%b');
            $month=substr($pre_month, 0, 6);
			$day = \Carbon\Carbon::parse($this->start_date)
			                     ->formatLocalized('%d');
		}
		else
		{
			$pre_month = \Carbon\Carbon::now()
			                     ->formatLocalized('%b');
            $month=substr($pre_month, 0, 6);
			$day = \Carbon\Carbon::now()
			                     ->formatLocalized('%d');
		}

		return '<span class="day">'.$day.'</span>'.'<span class="month">'.$month.'</span>';
	}

	public function scopeServicesFilters($query)
	{
		if (session()->has('searchServiceString'))
		{
			$search = session()->get('searchServiceString');

			$query->where('name', 'like', "%$search%");
		}

		if (session()->has('searchServiceEvent'))
		{
			$query->where('event', session()->get('searchServiceEvent'));
		}

		if (session()->has('searchServiceTrainers'))
		{
			$trainers = \App\Models\Trainer::whereIn('id', session()->get('searchServiceTrainers'))
			                               ->get();

			foreach ($trainers as $trainer)
			{
				foreach ($trainer->services as $item)
				{
					$services[] = $item->id;
				}
			}

			if (empty($services))
			{
				$query->where('id', 0);
			}
			else
			{
				$query->whereIn('id', $services);
			}
		}

		if (session()->has('searchServiceSpecialization'))
		{
			$ids = \DB::table('service_specialization')
			          ->where('specialization_id', session()->get('searchServiceSpecialization'))
			          ->pluck('service_id');

			$query->whereIn('id', $ids);
		}

		return $query;
	}


	public function scopeTrainingsFilters($query)
	{
		if (session()->has('searchTrainingString'))
		{
			$search = session()->get('searchTrainingString');

			$query->where('name', 'like', "%$search%");
		}

		if (session()->has('searchTrainingEvent'))
		{
			$query->where('event', session()->get('searchTrainingEvent'));
		}

		if (session()->has('searchTrainingEventType'))
		{
			$query->where('event_type', session()->get('searchTrainingEventType'));
		}

		if (session()->has('searchTrainingStartDate'))
		{
			$query->where('start_date', '>=', session()->get('searchTrainingStartDate'));
		}

		if (session()->has('searchTrainingEndDate'))
		{
			$query->where('end_date', '<=', session()->get('searchTrainingEndDate'));
		}

		if (session()->has('searchTrainingTrainers'))
		{
			$trainers = \App\Models\Trainer::whereIn('id', session()->get('searchTrainingTrainers'))
			                               ->get();

			foreach ($trainers as $trainer)
			{
				foreach ($trainer->services as $item)
				{
					$services[] = $item->id;
				}
			}

			if (empty($services))
			{
				$query->where('id', 0);
			}
			else
			{
				$query->whereIn('id', $services);
			}
		}

		if (session()->has('searchTrainingCityId'))
		{
			$ids = \App\Models\ServicePlace::where('city_id', session()->get('searchTrainingCityId'))
			                               ->get()
			                               ->pluck('service_id');

			$query->whereIn('id', $ids);
		}

		if (session()->has('searchTrainingSpecialization'))
		{
			$ids = \DB::table('service_specialization')
			          ->where('specialization_id', session()->get('searchTrainingSpecialization'))
			          ->pluck('service_id');

			$query->whereIn('id', $ids);
		}

		return $query;
	}
}
