<?php

use Illuminate\Database\Seeder;

class PackagesTableSeeder extends Seeder {
	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		$packages = [
			[
				'id' => 1,
				'name' => 'Легкий старт',
				'services' => 1,
				'articles' => 1,
				'multiple' => false,
				'tenders' => false,
				'report' => false,
				'vip_company' => false,
				'vip_trainers' => null,
				'hot_services' => null,
				'sale' => null,
				'price_one_months' => null,
				'price_three_months' => null,
				'price_six_months' => null,
				'default' => true,
				'default_registration' => true,
				'manager' => false,
				'punkt15' => null,
				'punkt16' => null,				
				'punkt17' => null,
				'punkt18' => null,
				'punkt19' => false,
				'punkt20' => null,
				'punkt21' => false,
				'punkt22' => false,
				'punkt23' => false,
				'punkt24' => false,
				'punkt25' => false,
				'punkt26' => null,
				'punkt27' => false																
			],
			[
				'id' => 2,
				'name' => 'Бизнес',
				'services' => null,
				'articles' => null,
				'multiple' => true,
				'tenders' => true,
				'report' => true,
				'vip_company' => false,
				'vip_trainers' => 3,
				'hot_services' => 3,
				'sale' => null,
				'price_one_months' => 360,
				'price_three_months' => 1080,
				'price_six_months' => 2160,
				'default' => false,
				'default_registration' => false,
				'manager' => false,
				'punkt15' => 3,
				'punkt16' => 3,				
				'punkt17' => 5,
				'punkt18' => 2,
				'punkt19' => true,
				'punkt20' => 1,
				'punkt21' => false,
				'punkt22' => false,
				'punkt23' => false,
				'punkt24' => false,
				'punkt25' => true,
				'punkt26' => 10,
				'punkt27' => true																

			],
			[
				'id' => 3,
				'name' => 'VIP',
				'services' => null,
				'articles' => null,
				'multiple' => true,
				'tenders' => true,
				'report' => true,
				'vip_company' => true,
				'vip_trainers' => 10,
				'hot_services' => 11,
				'sale' => 20,
				'price_one_months' => 1200,
				'price_three_months' => 3600,
				'price_six_months' => 7200,
				'default' => false,
				'default_registration' => false,
				'manager' => true,
				'punkt15' => 10,
				'punkt16' => 10,				
				'punkt17' => 15,
				'punkt18' => 6,
				'punkt19' => true,
				'punkt20' => 1,
				'punkt21' => true,
				'punkt22' => false,
				'punkt23' => false,
				'punkt24' => false,
				'punkt25' => true,
				'punkt26' => 25,
				'punkt27' => true																

			],
		];

		DB::table('packages')
		  ->insert($packages);

		foreach (App\Models\User::all() as $item)
		{
			if ($item->id > 2)
			{
				$hit = rand(2, 3);

				$id = DB::table('payments')
				        ->insertGetId([
					        'user_id' => $item->id,
					        'package_id' => $hit,
					        'price' => $packages[$hit - 1]['price_one_months'],
					        'duration' => 1,
					        'paid' => true,
					        'expired' => \Carbon\Carbon::now()
					                                   ->addMonth()
					                                   ->format('Y-m-d'),
					        'created_at' => \Carbon\Carbon::now(),
					        'updated_at' => \Carbon\Carbon::now(),
				        ]);

				DB::table('payments')
				  ->insert([
					  'user_id' => $item->id,
					  'package_id' => $hit,
					  'price' => $packages[$hit - 1]['price_one_months'],
					  'duration' => 1,
					  'paid' => true,
					  'expired' => \Carbon\Carbon::now()
					                             ->format('Y-m-d'),
					  'created_at' => \Carbon\Carbon::now()
					                                ->subMonth(),
					  'updated_at' => \Carbon\Carbon::now()
					                                ->subMonth(),
				  ]);

				DB::table('payments')
				  ->insert([
					  'user_id' => $item->id,
					  'package_id' => $hit,
					  'price' => $packages[$hit - 1]['price_one_months'],
					  'duration' => 1,
					  'paid' => true,
					  'expired' => \Carbon\Carbon::now()
					                             ->subMonth()
					                             ->format('Y-m-d'),
					  'created_at' => \Carbon\Carbon::now()
					                                ->subMonths(2),
					  'updated_at' => \Carbon\Carbon::now()
					                                ->subMonths(2),
				  ]);

				$item->payment_id = $id;

				$item->save();
			}
		}

		foreach (DB::table('payments')
		           ->get() as $referral)
		{
			if (!is_null($referral->price))
			{
				$user = \App\Models\User::find($referral->user_id);

				if (!is_null($user->referral_first_level))
				{
					$referral_first_level = \App\Models\User::where('code', $user->referral_first_level)
					                                        ->first();

					if ($referral_first_level)
					{
						DB::table('referrals_payment')
						  ->insert([
							  'user_id' => $referral->user_id,
							  'referral_id' => $referral_first_level->id,
							  'price' => number_format($referral->price / 100, 2, '.', ''),
							  'created_at' => \Carbon\Carbon::now(),
							  'updated_at' => \Carbon\Carbon::now(),
						  ]);
					}
				}

				if (!is_null($user->referral_second_level))
				{
					$referral_second_level = \App\Models\User::where('code', $user->referral_second_level)
					                                         ->first();

					if ($referral_second_level)
					{
						DB::table('referrals_payment')
						  ->insert([
							  'user_id' => $referral->user_id,
							  'referral_id' => $referral_second_level->id,
							  'price' => number_format($referral->price / 200, 2, '.', ''),
							  'created_at' => \Carbon\Carbon::now(),
							  'updated_at' => \Carbon\Carbon::now(),
						  ]);
					}
				}
			}
		}

		foreach (App\Models\User::all() as $item)
		{
			$summa = \App\Models\ReferralPayment::where('referral_id', $item->id)
			                                    ->sum('price');
			if($summa)
			{
				$item->total_summa = $summa;
				$item->current_summa = $summa;

				$item->save();
			}
		}
	}
}
