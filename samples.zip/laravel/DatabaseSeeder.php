<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder {
	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		$this->call(CitiesTableSeeder::class);
		$this->call(UsersTableSeeder::class);
		$this->call(SpecializationsTableSeeder::class);
		$this->call(TrainersTableSeeder::class);
		$this->call(CompaniesTableSeeder::class);
		$this->call(TendersTableSeeder::class);
		$this->call(ServicesTableSeeder::class);
		$this->call(BidsTableSeeder::class);
		$this->call(NewsTableSeeder::class);
		$this->call(ArticleTableSeeder::class);
		$this->call(CommentsTableSeeder::class);
		$this->call(StaticPageSeeder::class);
		$this->call(PackagesTableSeeder::class);
		$this->call(BannersTableSeeder::class);
		$this->call(TrainerPhotoVideoTableSeeder::class);
		$this->call(BlogsTableSeeder::class);
    	$this->call(FreematerialsTableSeeder::class);
    	$this->call(KnowledgesTableSeeder::class);
	}
}
