@extends('base/page')

@section('title')
	<title>{!! $article->title !!}</title>
@stop

@section('meta')
	<meta name="description" content="{!! $article->title !!}" />
	<meta name="keywords" content="" />
@stop
@section('breadcrumb')
<div class="breadcrumb-block uk-margin-top-remove">
	<div class="uk-container uk-container-center">
		<ul class="uk-breadcrumb">
			<li><a href="/">Главная</a></li>
                        <li><a href="{!! action('PublicController@getArticles') !!}">Статьи</a></li>
			<li class="uk-active"><span>{!! $article->title !!}</span></li>
		</ul>
	</div>
</div>
@stop
@section('content')
	<div class="main">
		<div class="uk-grid">
			<div class="uk-width-medium-7-10 uk-width-small-1-1">
				<div class="uk-grid">
					<div class="uk-width-1-1 article-full">
						<div class="uk-grid">
                            <img src="{!! $article->photo !!}" alt="">
							<div class="uk-width-1-1">
								<h1 class="uk-text-uppercase">{!! $article->title !!}</h1>
							</div>
							<div class="uk-width-1-1 meta">
								<span class="first"><i class="uk-icon-clock-o"></i> {!! $article->created_at !!}</span>
								<span><i class="uk-icon-eye"></i> Просмотры: {!! $article->views_count !!}</span>
								<span><i class="uk-icon-comment-o"></i> Комментариев: {!! $article->comments_count !!}</span>
							</div>
							<div class="uk-width-1-1 meta">
								<span class="first">
									@foreach($article->specialization as $specialization)
										<a href="{!! action('PublicController@getArticles', $specialization->url) !!}" class="dash-separated">
											{!! $specialization->name !!}
										</a>
									@endforeach
								</span>
								<span>
									<a href="{!! action('PublicController@getProfessional', $article->professional_id) !!}">{!! $article->professional->getLongnameAttribute() !!}</a>
								</span>
							</div>
							<div class="uk-width-1-1">
								{!! $article->text !!}
							</div>
							<div class="uk-width-1-1 uk-margin">
								@include('partials/socialShareWidget')
							</div>
						</div>
						<br />
						<br />
						@include('partials/comments', ['article' => $article])
					</div>
				</div>
			</div>
			<div class="uk-width-medium-3-10 uk-width-small-1-1">
				<h2>Рубрики</h2>
				<ul class="uk-nav uk-nav-side">
					@foreach($categories as $item)
						<li><a href="{!! action('PublicController@getArticles', $item->url) !!}">{!! $item->name !!}</a></li>
					@endforeach
				</ul>
				<br/>
				@include('partials/sidebar')
			</div>
		</div>
	</div>



	<div id="modal_e" class="uk-modal">
		<div class="uk-modal-dialog uk-modal-dialog-small">
			<button type="button" class="uk-modal-close uk-close"></button>
			<div class="modal-body">
				Доступ к публикациям открыт для зарегистрированных читателей WEBSMART<br>
				Станьте читателем блога наших высококвалифицированных профессионалов и получите:<br>
				— полный доступ ко всем свежим статьям;<br>
				— получение рассылки о новых тренингах и новых статьях;<br>
				— общение и участие в профессиональных блогах.<br>
			</div>
			<div class="uk-modal-footer uk-text-center">
				<a href="{!! action('AuthController@getRegistration') !!}" class="uk-button uk-button-primary">Регистрация</a>
			</div>
		</div>
	</div>

@stop
@section('js')
@stop

@section('scripts')
	<script type="text/javascript">
		$('.uk-navbar-nav li:has(a[href="{!! action('PublicController@getArticles') !!}"])').addClass('uk-active');
	</script>
@stop
