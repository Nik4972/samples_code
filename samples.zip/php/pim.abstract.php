<?php

abstract class PimOperationsAbstract {

    const typeInt = 1;
    const typeIntNull = 11;
    const typeBool = 2;

    static function validate($data, $validKeys, $validatePrm = true) {
        if (empty($data[PimInputKeys::MspId])) {
            throw new Exception(PimInputKeys::MspId . ' is required');
        }

        if($validatePrm){
            if (empty($data[PimInputKeys::Params])) {
                throw new Exception(PimInputKeys::Params . ' is required');
            }

            foreach ($validKeys as $param => $rule) {
                if (array_key_exists(PimValidParams::Required, $rule)) {
                    if (array_key_exists(PimValidParams::AllowNull, $rule)) {
                        if (!array_key_exists($param, $data[PimInputKeys::Params])) {
                            throw new Exception($param . ' is required');
                        }
                    }
                    elseif (!isset($data[PimInputKeys::Params][$param])) {
                        throw new Exception($param . ' is required and must not be empty');
                    }

                }

                if (array_key_exists(PimValidParams::DependsOn, $rule)
                    && empty($data[PimInputKeys::Params][$rule[PimValidParams::DependsOn]])
                    && empty($data[PimInputKeys::Params][$param])) {
                    throw new Exception($param . ' is required because '. $rule[PimValidParams::DependsOn] .'  is not provided');
                }

                if (array_key_exists(PimValidParams::IsArray, $rule) && !is_array($data[PimInputKeys::Params][$param])) {
                    throw new Exception($param . ' should be as array');
                }
            }
        }
    }

    static function switchToMspDb($mspId) {
        $dbName = 'msp_'.$mspId;
        if (!db_select_database($dbName))
            throw new Exception('Unable to select the database ' . $dbName);
        
        global $ost, $cfg;   
        if(!($ost=osTicket::start()) || !($cfg = $ost->getConfig()))
            throw new Exception('Unable to load config info from DB. Get tech support.');

    }
    
    static function copyFields($inArr, $typeArr){
        $outArr = array();

        foreach($inArr as $key => $item){
            if(isset($typeArr[$key])){
                switch($typeArr[$key]){
                    case self::typeInt:
                        $outArr[$key] = (int)$item;
                        break;
                    case self::typeIntNull:
                        $outArr[$key] = isset($item) ? (int)$item : null;
                        break;
                    case self::typeBool:
                        $outArr[$key] = $item == 1;
                        break;
                    default:
                        $outArr[$key] = $item;
                        break;
                }
            }
            else $outArr[$key] = $item;
        }
        return $outArr;
    }
    
    static function success($data=null, $message=null) {
        return array(
            PimOutputKeys::Status  => PimOutputValues::Success,
            PimOutputKeys::Code    => PimOutputValues::CodeOK,
            PimOutputKeys::Message => $message,
            PimOutputKeys::Data    => $data,
            PimOutputKeys::Date    => date("Y-m-d H:i:s"));  
    }
    
    static function error($message, $code=PimOutputValues::CodeError) {
        return array(
            PimOutputKeys::Status  => PimOutputValues::Error,
            PimOutputKeys::Code    => $code,
            PimOutputKeys::Message => $message,
            PimOutputKeys::Data    => null,
            PimOutputKeys::Date    => date("Y-m-d H:i:s"));    
    }
    
    static function sql_error() {
        return self::error('SQL error');
    }
    
    static function exception($ex) {
        log_error(array('msg' => $ex->getMessage()), PIM_LOG);
        return self::error('unexpected error occurred!', PimOutputValues::CodeError);    
    }

}