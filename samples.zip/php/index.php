<?php

$here = dirname(__FILE__);
$here = ($h = realpath($here)) ? $h : $here;
define('DEFAULT_ROOT_DIR',str_replace('\\', '/', $here.'/') .'../');
unset($here); unset($h);

define('DISABLE_SESSION', true);

require_once(DEFAULT_ROOT_DIR.'main.inc.php');
require_once(DEFAULT_ROOT_DIR.'include/logger.php');


define('PIM_LOG', 'pim.log');

require_once('pim.constants.php');
require_once('admin.php');
require_once('company.php');
require_once('msp.php');
require_once('ticket.php');

require_once('mobile.php');

$string = file_get_contents('php://input');
$data = json_decode($string, true);

$results = null;
try {
    if (empty($data)) {
        throw new Exception("Incorrect JSON format: ". (function_exists('json_last_error_msg')? json_last_error_msg() : ''));
    }

    if ($data[PimInputKeys::TargetApiKey] != SSO_API_KEY) {
            throw new Exception(PimInputKeys::TargetApiKey . " does not matched");
    }
    
    if ($data[PimInputKeys::RequestType] == PimInputValues::PimEvent) {

        switch ($data[PimInputKeys::EventName]) {
            // MSP operations
            case PimInputValues::MspCreated:
                $results = MspOperations::createMsp($data);
                break;
            case PimInputValues::MspUpdated:
                $results = MspOperations::updateMsp($data);
                break;
            case PimInputValues::MspDeleted:
                $results = MspOperations::deleteMsp($data);
                break;

            // Company operations
            case PimInputValues::CompanyCreated:
                $results = CompanyOperations::createCompany($data);
                break;
            case PimInputValues::CompanyUpdated:
                $results = CompanyOperations::updateCompany($data);
                break;
            case PimInputValues::CompanyDeleted:
                $results = CompanyOperations::deleteCompany($data);
                break;

            // Admin operations
            case PimInputValues::AdminCreated:
                $results = AdminOperations::createAdmin($data);
                break;
            case PimInputValues::AdminUpdated:
                $results = AdminOperations::updateAdmin($data);
                break;
            case PimInputValues::AdminDeleted:
                $results = AdminOperations::deleteAdmin($data);
                break;

            default:
                throw new Exception("Unknown event");
        }
    }

    if ($data[PimInputKeys::RequestType] == PimInputValues::PimService) {
        switch ($data[PimInputKeys::ServiceName]) {
            // Ticket operations
            case PimInputValues::CreateTicket:
                $results = TicketOperations::createTicket($data);
                break;
            case PimInputValues::CloseTicket:
                $results = TicketOperations::closeTicket($data);
                break;
            case PimInputValues::SearchTicket:
                $results = TicketOperations::searchTicket($data);
                break;
            case PimInputValues::ReopenTicket:
                $results = TicketOperations::reopenTicket($data);
                break;
            case PimInputValues::CompanyTicket:
                $results = TicketOperations::companyTicket($data);
                break;
            case PimInputValues::TotalTicket:
                $results = TicketOperations::totalTicket($data);
                break;
            
            /**
             * PIM extension for mobile apps
             */ 
            case PimInputValues::getStaffTicketStatistics:
                $results = MobileOps::getStaffTicketStatistics($data);
                break;
            case PimInputValues::getStaffInfo:
                $results = MobileOps::getStaffInfo($data);
                break;
            case PimInputValues::getStaffs:
                $results = MobileOps::getStaffs($data);
                break;

            case PimInputValues::getUsers:
                $results = MobileOps::getUsers($data);
                break;
            
            case PimInputValues::getDepartments:
                $results = MobileOps::getDepartments($data);
                break;
            
            case PimInputValues::getSLAs:
                $results = MobileOps::getSLAs($data);
                break;

            case PimInputValues::getHelpTopics:
                $results = MobileOps::getHelpTopics($data);
                break;
            
            case PimInputValues::getFormInfo:
                $results = MobileOps::getFormInfo($data);
                break;

            case PimInputValues::getDictionaries:
                $results = MobileOps::getDictionaries($data);
                break;
 
            case PimInputValues::getTickets:
                $results = MobileOps::getTickets($data);
                break;

            case PimInputValues::ticketOp:
                $results = MobileOps::ticketOp($data);
                break;
            
            case PimInputValues::subscribeNotifications:
                $results = MobileOps::subscribeNotifications($data);
                break;
            
            
            default:
                throw new Exception("Unknown service");
        }
    }

} catch (Exception $exception) {
    log_error(array('msg' => $exception->getMessage()), PIM_LOG);
    $results = array(
        PimOutputKeys::Sender   => PimOutputValues::TargetPim,
        PimOutputKeys::Status   => PimOutputValues::Error,
        PimOutputKeys::Code     => PimOutputValues::CodeError,
        PimOutputKeys::Message  => 'unexpected error occurred!',
        PimOutputKeys::Data     => null,
    );
}

header('Content-Type: application/json');
echo json_encode($results);


