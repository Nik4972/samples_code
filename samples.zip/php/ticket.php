<?php

// TODO: Refactor it
require_once('pim.constants.php');
require_once('pim.abstract.php');

class TicketOperations extends PimOperationsAbstract {
    const TicketId = 'ticketId';
    const Subject = 'subject';
    const Message = 'message';
    const Token = 'token';
    const Email = 'email';
    const CompanyId = 'companyId';
    const PriorityId = 'priorityId';
    const PortalUserId = 'portalUserId';
    const Source = 'source';
    const Status = 'status';
    const IDS = 'IDS';
    const MspId = 'mspId';
    
    static function createTicket($data)
    {
        try {
            $validKeys = array(
                self::Subject   => array(PimValidParams::Required => true),
                self::Message   => array(PimValidParams::Required => true),
                self::CompanyId => array(PimValidParams::Required => true),
            );

            self::validate($data, $validKeys);
            self::switchToMspDb($data[PimInputKeys::MspId]);


            // Get company name
            $organization = Organization::lookup(array('portal_id' => $data[PimInputKeys::Params][self::CompanyId]));
            if (empty($organization)) {
                throw new Exception("Company with this id (".$data[PimInputKeys::Params][self::CompanyId].") is not found in the database");
            }

            $companyName = $organization->get('name');
            $companyName = str_replace(' ', '', $companyName);

            // Hardcoded, because request may not contain email, but ticket is needed email
            if (empty($data[PimInputKeys::Params][self::Email])) {
                $email = 'agent.monitor@'.$companyName;

                log_info(array('log_name' => 'create_ticket', 'msp_id' => $data[PimInputKeys::MspId], 'company_id' => $data[PimInputKeys::Params][self::CompanyId],
                    'msg' => "There is empty email for creating ticket, so email will be '{$email}'"), PIM_LOG);

                // If user with default email not exists - create new (for osTicket working)
                User::__create(array(
                    'name'      => 'Default Ticket User',
                    'email'     => $email,
                    'org_id'    => $organization->get('id'),
                ));

            } else {
                $email = self::getEmailAndCheckAdminExists($data);
            }

            $dbData = array(
                'subject'   => $data[PimInputKeys::Params][self::Subject],
                'message'   => $data[PimInputKeys::Params][self::Message],
                'email'     => $email,
                'source'    => 'Other',
                // c1 portal fields
                'portal_source' => $data[PimInputKeys::Params][self::Source],
                'company_id'    => $data[PimInputKeys::Params][self::CompanyId],
                'priorityId' => $data[PimInputKeys::Params][self::PriorityId],
            );
            $errors = array();
            $ticket = Ticket::create($dbData, $errors, 'api', false);

            if (!empty($errors)) {
                throw new Exception("DB Error: ".json_encode($errors));
            }

            log_info(array('log_name' => 'create_ticket', 'msp_id' => $data[PimInputKeys::MspId], 'company_id' => $data[PimInputKeys::Params][self::CompanyId],
                'msg' => "Ticket Created"), PIM_LOG);

            // Result
            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Success,
                PimOutputKeys::Code     => PimOutputValues::CodeOK,
                PimOutputKeys::Message  => "Ticket Created",
                PimOutputKeys::Data     => array(
                    'ticketId' => $ticket->getId(),
                ),
            );
        } catch (Exception $exception) {
            log_error(array('msg' => $exception->getMessage()), PIM_LOG);
            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Error,
                PimOutputKeys::Code     => PimOutputValues::CodeError,
                PimOutputKeys::Message  => 'unexpected error occurred!',
                PimOutputKeys::Data     => null,
            );
        }

        return $results;
    }

    static function closeTicket($data)
    {
        try {
            $validKeys = array(
                self::TicketId  => array(PimValidParams::Required => true),
                self::CompanyId => array(PimValidParams::Required => true),
            );

            self::validate($data, $validKeys);
            self::switchToMspDb($data[PimInputKeys::MspId]);


            $ticket = Ticket::lookup($data[PimInputKeys::Params][self::TicketId]);

            if (empty($ticket)) {
                throw new Exception('Ticket with this id ('.$data[PimInputKeys::Params][self::TicketId].') is not found in the database');
            }

            $ticket->setStatus('closed');

            log_info(array('log_name' => 'close_ticket', 'msp_id' => $data[PimInputKeys::MspId], 'ticket_id' => $data[PimInputKeys::Params][self::TicketId],
                'msg' => "Ticket closed"), PIM_LOG);

            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Success,
                PimOutputKeys::Code     => PimOutputValues::CodeOK,
                PimOutputKeys::Message  => "Ticket Closed",
                PimOutputKeys::Data     => null,
            );
        } catch (Exception $exception) {
            log_error(array('msg' => $exception->getMessage()), PIM_LOG);
            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Error,
                PimOutputKeys::Code     => PimOutputValues::CodeError,
                PimOutputKeys::Message  => 'unexpected error occurred!',
                PimOutputKeys::Data     => null,
            );
        }

        return $results;
    }

    static function searchTicket($data)
    {
        try {
            $validKeys = array(
                self::CompanyId => array(PimValidParams::Required => true),
            );

            self::validate($data, $validKeys);
            self::switchToMspDb($data[PimInputKeys::MspId]);


            // Get list of tickets
            $params = array();
            if (!empty($data[PimInputKeys::Params][self::Status])) $params['status'] = $data[PimInputKeys::Params][self::Status];
            if (!empty($data[PimInputKeys::Params][self::Source])) $params['portal_source'] = $data[PimInputKeys::Params][self::Source];
            if (!empty($data[PimInputKeys::Params][self::CompanyId])) $params['company_id'] = $data[PimInputKeys::Params][self::CompanyId];

            $tickets = Ticket::getTicketsByParams($params);

            log_info(array('log_name' => 'search_ticket', 'msp_id' => $data[PimInputKeys::MspId], 'company_id' => $data[PimInputKeys::Params][self::CompanyId],
                'msg' => 'Ticket search - result count: '.count($tickets)), PIM_LOG);

            $results = array(
                PimOutputKeys::Sender   => PimOutputValues::TargetPim,
                PimOutputKeys::Status   => PimOutputValues::Success,
                PimOutputKeys::Code     => PimOutputValues::CodeOK,
                PimOutputKeys::Message  => "Ticket Search",
                PimOutputKeys::Data     => array(),
            );
            if (!empty($tickets)) {
                foreach ($tickets as $ticket) {
                    $results[PimOutputKeys::Data][] = array(
                        'mspId'         => $data[PimInputKeys::MspId],
                        'number'        => $ticket->getId(),
                        'created'       => $ticket->getCreateDate(),
                        'from'          => $ticket->getEmail(),
                        'assignedTo'    => $ticket->getAssigned(', '),
                        'status'        => $ticket->getStatus(),
                        'priority'      => $ticket->getPriority(),
                        'subject'       => $ticket->getSubject(),
                    );
                }
            }
        } catch (Exception $exception) {
            log_error(array('msg' => $exception->getMessage()), PIM_LOG);
            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Error,
                PimOutputKeys::Code     => PimOutputValues::CodeError,
                PimOutputKeys::Message  => 'unexpected error occurred!',
                PimOutputKeys::Data     => null,
            );
        }

        return $results;
    }

    static function reopenTicket($data)
    {
        try {
            $validKeys = array(
                self::TicketId  => array(PimValidParams::Required => true)
            );

            self::validate($data, $validKeys);
            self::switchToMspDb($data[PimInputKeys::MspId]);

            $ticketID = $data[PimInputKeys::Params][self::TicketId];
            $msg = is_null($data[PimInputKeys::Params][self::Message]) ? 'Ticket reopened (without comments)' : $data[PimInputKeys::Params][self::Message];
            $poster = is_null($data[PimInputKeys::Params][self::Source]) ? 'FROM API' : $data[PimInputKeys::Params][self::Source] . ' - FROM API';

            $ticket = Ticket::lookup($ticketID);

            if (empty($ticket)) {
                throw new Exception('Ticket with this id ('.$ticketID.') is not found in the database');
            }

            $ticket->reopen();

            $sql=' INSERT INTO '.TICKET_THREAD_TABLE.' SET created=NOW() '
                .' ,thread_type="n"'
                .' ,ticket_id='.db_input($ticketID)
                .' ,title="Ticket Reopened"'
                .' ,format="html"'
                .' ,staff_id=0'
                .' ,user_id=0'
                .' ,poster="' . db_input($poster) .'"'
                .' ,source=""'
                .', body="' . db_input($msg) . '"';

            db_query($sql);

            log_info(array('log_name' => 'reopen_ticket', 'msp_id' => $data[PimInputKeys::MspId], 'ticket_id' => $ticketID,
                'msg' => 'Ticket reopened'), PIM_LOG);

            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Success,
                PimOutputKeys::Code     => PimOutputValues::CodeOK,
                PimOutputKeys::Message  => "Ticket Reopened",
                PimOutputKeys::Data     => null,
            );
        } catch (Exception $exception) {
            log_error(array('msg' => $exception->getMessage()), PIM_LOG);
            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Error,
                PimOutputKeys::Code     => PimOutputValues::CodeError,
                PimOutputKeys::Message  => 'unexpected error occurred!',
                PimOutputKeys::Data     => null,
            );
        }

        return $results;
    }

    private static function statTicket($id)
    {


            $stats = array();

            $sql = 'SELECT email, lastlogin, firstname FROM '.STAFF_TABLE.' WHERE staff_id = 1';
            $mspDetails = db_fetch_row(db_query($sql));

            $sql = 'SELECT COUNT(1) AS total FROM '.TICKET_TABLE.' WHERE status = "open"';
            $openTickets = db_fetch_row(db_query($sql));

            $sql = 'SELECT COUNT(1) AS total FROM '.TICKET_TABLE.' WHERE status = "open" AND created > DATE_SUB(now(), INTERVAL 1 DAY)';
            $openTickets24Hours = db_fetch_row(db_query($sql));

            $sql = 'SELECT COUNT(1) AS total FROM '.TICKET_TABLE.' WHERE status = "open" AND created > DATE_SUB(now(), INTERVAL 2 DAY)';
            $openTickets48Hours = db_fetch_row(db_query($sql));

            $sql = 'SELECT COUNT(1) AS total FROM '.TICKET_TABLE.' WHERE status = "closed" AND created > DATE_SUB(now(), INTERVAL 1 DAY)';
            $closedTickets24Hours = db_fetch_row(db_query($sql));

            $sql = 'SELECT COUNT(1) AS total FROM '.TICKET_TABLE.' WHERE status = "closed" AND created > DATE_SUB(now(), INTERVAL 2 DAY)';
            $closedTickets48Hours = db_fetch_row(db_query($sql));

            $sql = 'SELECT COUNT(1) AS total FROM '.TICKET_TABLE.' WHERE status = "closed"';
            $closedTickets = db_fetch_row(db_query($sql));

            $sql = 'SELECT COUNT(1) AS total FROM '.TICKET_TABLE.' WHERE status = "open" AND staff_id=0 AND team_id=0';
            $unassignedTickets = db_fetch_row(db_query($sql));

            $sql = 'SELECT COUNT(1) AS total FROM '.TICKET_TABLE.' WHERE isoverdue=1';
            $overdueTickets = db_fetch_row(db_query($sql));

            $stats[$id]['details'] = $mspDetails;
            $stats[$id]['openTickets'] = intval($openTickets[0]);
            $stats[$id]['openTickets24Hours'] = intval($openTickets24Hours[0]);
            $stats[$id]['openTickets48Hours'] = intval($openTickets48Hours[0]);
            $stats[$id]['closedTickets'] = intval($closedTickets[0]);
            $stats[$id]['closedTickets24Hours'] = intval($closedTickets24Hours[0]);
            $stats[$id]['closedTickets48Hours'] = intval($closedTickets48Hours[0]);
            $stats[$id]['unassignedTickets'] = intval($unassignedTickets[0]);
            $stats[$id]['overdueTickets'] = intval($overdueTickets[0]);
            $stats[$id]['total'] = $closedTickets[0] + $openTickets[0];


        return $stats;
    }

    public static function companyTicket($data)
    {
        try {
            $validKeys = array(
                self::IDS  => array(PimValidParams::Required => true)
            );

            self::validate($data, $validKeys);

            $ids = $data[PimInputKeys::Params][self::IDS];

            $stats = array();

            foreach ($ids as $mspID => $companyIds) {

                foreach($companyIds as $companyId) {

                    try {
                        self::switchToMspDb($mspID);
                    } catch (Exception $e) {
                        $stats[$mspID] = 'MSP_NOT_FOUND';
                        continue;
                    }

                    if($companyId == "0") {
                        $stats[$mspID] = self::statTicket($companyId);
                    } else {
                        $sql = 'SELECT id FROM '.ORGANIZATION_TABLE.' WHERE portal_id = ' . db_input($companyId) . ' LIMIT 1';
                        $companyCheck = db_fetch_row(db_query($sql));
                        if (is_null($companyCheck)) {
                            $stats[$mspID][$companyId] = 'COMPANY_NOT_FOUND';
                            continue;
                        }

                        $sql = 'SELECT email, lastlogin, firstname FROM '.STAFF_TABLE.' WHERE staff_id = 1';
                        $mspDetails = db_fetch_row(db_query($sql));

                        $sql = 'SELECT COUNT(1) FROM '.ORGANIZATION_TABLE.' AS organization
                            LEFT JOIN '.USER_TABLE.' AS user ON user.org_id = organization.id
                            LEFT JOIN '.TICKET_TABLE.' AS ticket ON ticket.user_id = user.id
                            WHERE ticket.status = "open" AND organization.portal_id = ' . db_input($companyId);;
                        $openTickets = db_fetch_row(db_query($sql));

                        $sql = 'SELECT COUNT(1) FROM '.ORGANIZATION_TABLE.' AS organization
                            LEFT JOIN '.USER_TABLE.' AS user ON user.org_id = organization.id
                            LEFT JOIN '.TICKET_TABLE.' AS ticket ON ticket.user_id = user.id
                            WHERE ticket.status = "closed" AND organization.portal_id = ' . db_input($companyId);;
                        $closedTickets = db_fetch_row(db_query($sql));

                        $sql = 'SELECT COUNT(1) FROM '.ORGANIZATION_TABLE.' AS organization
                            LEFT JOIN '.USER_TABLE.' AS user ON user.org_id = organization.id
                            LEFT JOIN '.TICKET_TABLE.' AS ticket ON ticket.user_id = user.id
                            WHERE ticket.status = "open" AND ticket.staff_id=0 AND ticket.team_id=0 AND organization.portal_id = ' . db_input($companyId);

                        $unassignedTickets = db_fetch_row(db_query($sql));

                        $sql = 'SELECT COUNT(1) FROM '.ORGANIZATION_TABLE.' AS organization
                            LEFT JOIN '.USER_TABLE.' AS user ON user.org_id = organization.id
                            LEFT JOIN '.TICKET_TABLE.' AS ticket ON ticket.user_id = user.id
                            WHERE ticket.isoverdue=1 AND organization.portal_id = ' . db_input($companyId);

                        $overdueTickets = db_fetch_row(db_query($sql));

                        $stats[$mspID][$companyId]['details'] = $mspDetails;
                        $stats[$mspID][$companyId]['openTickets'] = intval($openTickets[0]);
                        $stats[$mspID][$companyId]['closedTickets'] = intval($closedTickets[0]);
                        $stats[$mspID][$companyId]['unassignedTickets'] = intval($unassignedTickets[0]);
                        $stats[$mspID][$companyId]['overdueTickets'] = intval($overdueTickets[0]);
                        $stats[$mspID][$companyId]['total'] = $closedTickets[0] + $openTickets[0];
                    }
                }

            }

            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Success,
                PimOutputKeys::Code     => PimOutputValues::CodeOK,
                PimOutputKeys::Message  => "Company Stats",
                PimOutputKeys::Data     => $stats,
            );

            log_info(array('log_name' => 'company_ticket', 'company_ids' => $data[PimInputKeys::Params][self::IDS], 'msg' => 'Company ticket stats shown'), PIM_LOG);

        } catch (Exception $exception) {
            log_error(array('msg' => $exception->getMessage()), PIM_LOG);
            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Error,
                PimOutputKeys::Code     => PimOutputValues::CodeError,
                PimOutputKeys::Message  => 'unexpected error occurred!',
                PimOutputKeys::Data     => null,
            );
        }

        return $results;
    }

    public static function totalTicket($data)
    {

        global $__db;

        try {
            $sql = "SHOW DATABASES LIKE 'msp_%'";
            $mspDetails = db_query($sql);

            $stats = array();
            while($row = db_fetch_row($mspDetails)) {
                $stats[$row[0]] = $row[1];
            }

            $keys = array_keys($stats);

            $totalTicket = 0;
            foreach ($keys as $id) {
                $id = str_replace('msp_', '', $id);
                self::switchToMspDb($id);

                $sql = 'SELECT COUNT(1) FROM '.TICKET_TABLE;
                $res = $__db->query($sql);
                if($res == false) {
                    continue;
                }

                $totalTicketCount = db_fetch_row(db_query($sql));
                $totalTicket += intval($totalTicketCount[0]);
            }

            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Success,
                PimOutputKeys::Code     => PimOutputValues::CodeOK,
                PimOutputKeys::Message  => "Tickets Count",
                PimOutputKeys::Data     => array(
                    'total' => $totalTicket
                ),
            );

            log_info(array('log_name' => 'total_ticket', 'msg' => 'Total tickets count returned'), PIM_LOG);

        } catch (Exception $exception) {
            log_error(array('msg' => $exception->getMessage()), PIM_LOG);
            $results = array(
                PimOutputKeys::Status   => PimOutputValues::Error,
                PimOutputKeys::Code     => PimOutputValues::CodeError,
                PimOutputKeys::Message  => 'unexpected error occurred!',
                PimOutputKeys::Data     => null,
            );
        }

        return $results;
    }

    private static function getEmailAndCheckAdminExists($data)
    {
        if (!empty($data[PimInputKeys::Params][self::Token])) {
            $tokenResult = SSOServer::checkToken($data[PimInputKeys::Params][self::Token]);
            if (empty($tokenResult) || empty($tokenResult->data) || empty($tokenResult->data->email)) {
                throw new Exception("Can not get email by this token (" . $data[PimInputKeys::Params][self::Token] . ")");
            }
            $email = $tokenResult->data->email;
        } else {
            $email = $data[PimInputKeys::Params][self::Email];
        }

        // Check email for staff
        $admin = new Staff($email);
        if ($admin->getId() == 0) {
            throw new Exception("Admin with this email (" . $data[PimInputKeys::Params][self::Email] . ") is not found in the database");
        }

        return $email;
    }
}
